# Hete-Ensemble：基于颅内脑电的癫痫手术预后异质集成预测

本项目面向**耐药性癫痫手术预后预测**，基于多中心颅内脑电（iEEG，含 SEEG 与 ECoG 两种模态），构建由 **7 类特征域 × 5 种选择器 × 6 种分类器 × 6 个时间窗** 组合而成的**异质集成模型（Heterogeneous Ensemble）**，并以 **Leave-One-Center-Out（LOCO）** 跨中心验证协议评估其泛化能力。

---

## 1. 研究背景与目标

- **任务**：二分类预测患者术后是否达到 **Engel I 级（无发作，正类）**，Engel II–IV 为负类。
- **数据**：来自 4 个独立癫痫中心（LZUSH、CHFU、HUP、FMRS），共 155 例患者、536 次发作样本，同时包含 SEEG 与 ECoG 两种采集模态。
- **计算单元**：以 **EZ（致痫区）/ NEZ（非致痫区）** 两组通道为基本单元，组内统计聚合为固定维特征向量。

---

## 2. 方法总览

完整流水线分为三个阶段，对应 `src/Run/` 下的三个主脚本：

```text
Run_Data_Preprocess.py  →  数据预处理（时间窗截取 + 陷波 + 分频带滤波）
Run_Compute_Feature.py  →  7 域特征计算
Run_train_voting_center.py  →  异质专家集成训练、soft voting 聚合、LOCO 评估
```

### 2.1 预处理（`Run_Data_Preprocess.py`）

统一预处理流程：

1. **重采样**：在数据入库阶段完成，将原始采样率 `orig_sfreq` 统一为 `target_sfreq`。
2. **时间窗提取**：按 6 种配置截取。
3. **坏道剔除**。
4. **陷波滤波**：依中心不同，滤除 50 Hz 或 60 Hz 及其谐波。
5. **分频带滤波**：三条滤波流并行输出。

6 种时间窗配置：

| 配置 | 时长 | 截取方式 | 目录命名 |
|------|------|----------|----------|
| start | 10 / 20 / 30 秒 | 自发作起始向前截取 | `10start` / `20start` / `30start` |
| mid   | 10 / 20 / 30 秒 | 以发作中点为心向两侧截取 | `10mid` / `20mid` / `30mid` |

三条滤波流：

- `filter_01`：0.5 – 125 Hz 带通（用于 DWT / CWT / 神经脆性）。
- `filter_02`：80 – 500 Hz 带通（用于 HFO 检测）。
- `filter_03`：7 频带分割（delta / theta / alpha / beta / gamma1 / gamma2 / gamma3，用于 Spectral / Connectivity / Graph）。

### 2.2 七域特征（`Run_Compute_Feature.py`）

以 EZ / NEZ 两组通道为基本计算单元，组内统计聚合为固定维向量：

| 特征域 | 维度 | 主要方法 |
|--------|------|----------|
| Spectral | 364 | 7 频带 × 10 统计量 + 频带间比值 |
| DWT | 126 | Daubechies 4 小波，6 层分解 × 9 统计量 |
| CWT | 398 | Morlet 小波，8 尺度 × 幅值 / 相位统计量 |
| Functional Connectivity | 210 | Coherence / PLV / wPLI，7 频带 |
| Graph Theory | 126 | 加权强度 / 介数中心性 / 聚类系数 |
| HFOs | 100 | Hilbert 包络检测 Ripple 与 Fast Ripple |
| Neural Fragility | 390 | 线性状态转移模型，15 组参数，三层特征 |

每个时间窗目录下的 `feature/` 输出 7 个 CSV：`spectral_feature.csv`、`dwt_feature.csv`、`cwt_feature.csv`、`connectivity_feature.csv`、`graph_feature.csv`、`hfo_feature.csv`、`fragility_feature.csv`。

### 2.3 异质集成（`Run_train_voting_center.py`）

每个专家（expert）是一个 **(时间窗, 特征域, 特征选择器, 分类器)** 四元组。

**5 种特征选择器**（`src/selecor/`）：

| 选择器 | 对应文件 | 说明 |
|--------|----------|------|
| ANOVA F | `f_classif.py` | F 检验 |
| MI | `MI.py` | 互信息 |
| L1 | `L1.py` | L1 正则稀疏选择 |
| Boruta | `BR.py` | Boruta 全相关特征选择 |
| mRMR | `mRMR.py` | 最小冗余最大相关 |

> 除 Boruta 外，其余选择器统一降至 **40 维**。

**6 种分类器**（`src/classifier/`）：

| 分类器 | 文件 |
|--------|------|
| LDA | `LDA.py` |
| LR1（L1 逻辑回归） | `LR1.py` |
| LR2（L2 逻辑回归） | `LR2.py` |
| MLP | `mlp.py` |
| XGBoost | `XGB.py` |
| KNN | `KNN.py` |

**15 个专家的固定组合**：按覆盖规则人工选定，保证七域至少各一、5 种选择器与 6 种分类器全覆盖、6 个时间窗全覆盖、任意两专家至少在一维上不同。该规则不依赖任何性能指标，避免数据泄露。

**聚合方式**：soft voting —— 对各专家的预测概率取算术平均，并以全局统一阈值 **τ = 0.56** 得到二分类结果。

### 2.4 验证策略

采用 **Leave-One-Center-Out（LOCO）**：每折留出一个完整临床中心作测试集，其余三个中心作训练集，共 4 折。特征选择、模型训练、超参数与专家池构造全程不接触测试中心。最终指标在 **9 个随机种子**上聚合。

---

## 3. 项目目录结构

```text
Hete-Ensemble/
├── data/
│   ├── data.csv                         # 患者元数据（EZ/NEZ 通道、标签、中心、采样率等）
│   ├── iEEG/                            # 原始 iEEG 数据 (.fif)
│   ├── Example/                         # 示例数据的预处理与特征中间产物
│   │   └── {10,20,30}{start,mid}/
│   │       ├── crop/  notch/  filter_01/  filter_02/  filter_03/  feature/
│   └── {10,20,30}{start,mid}/feature/   # 全量数据的七域特征 CSV
├── src/
│   ├── Run/                             # 三个主运行脚本
│   │   ├── Run_Data_Preprocess.py
│   │   ├── Run_Compute_Feature.py
│   │   └── Run_train_voting_center.py
│   ├── preprocess/                      # 预处理
│   │   ├── crop.py / filter.py / utils.py
│   ├── feature/                         # 七域特征计算
│   │   ├── spectral_feature.py / dwt_feature.py / cwt_feature.py
│   │   ├── connectivity_feature.py / graph_feature.py
│   │   ├── hfo_feature.py / HFOdetection_Hilbert.py
│   │   └── fragility_feature.py / neural_fragility.py
│   ├── selecor/                         # 特征选择器
│   │   ├── f_classif.py / MI.py / L1.py / BR.py / mRMR.py
│   ├── classifier/                      # 分类器
│   │   ├── LDA.py / LR1.py / LR2.py / mlp.py / XGB.py / KNN.py
│   └── train/                           # 训练与评估
│       ├── load_data.py / split.py / expert_probs.py
│       ├── ensemble_eval.py / expert_eval.py / ablation_eval.py
│       ├── threshold_scan.py / eval_utils.py
└── README.md
```
注：Example文件夹只保留了10start，其他窗口通过脚本运行即可得到。
---

## 4. 数据格式说明

`data/data.csv` 为患者元数据，核心字段：

| 字段 | 说明 |
|------|------|
| `Dataset` | 所属临床中心（LZUSH / CHFU / HUP / FMRS / Example） |
| `patient_name` | 患者编号 |
| `sample_name` | 单次发作样本编号（.fif 文件名，不含后缀） |
| `orig_sfreq` / `target_sfreq` | 原始采样率 / 重采样目标采样率 |
| `EZ` | 致痫区通道索引列表 |
| `NEZ` | 非致痫区通道索引列表 |
| `isCured` | 标签：True = Engel I（正类），False = Engel II–IV |
| `Implant` | 植入模态（SEEG / ECoG） |
| `start_time` / `end_time` | 发作起止时间 |

原始 iEEG 以 `.fif` 格式存放于 `data/iEEG/{sample_name}.fif`。

---

## 5. 快速开始

### 5.1 环境依赖

- Python 3.8+
- 核心库：`numpy`、`pandas`、`scipy`、`mne`、`scikit-learn`、`xgboost`、`boruta`、`tqdm`、`matplotlib`

### 5.2 运行步骤

在项目根目录下依次执行：

**Step 1 — 数据预处理**

```bash
python -m src.Run.Run_Data_Preprocess
```

完成时间窗截取、陷波滤波、分频带滤波，结果写入 `data/Example/`（示例数据）。

**Step 2 — 七域特征计算**

```bash
python -m src.Run.Run_Compute_Feature
```

对 6 个时间窗分别计算七域特征，输出至 `data/Example/{window}/feature/`。

**Step 3 — 异质集成训练与评估**

```bash
python -m src.Run.Run_train_voting_center
```

依次完成：

1. `train_center_voting` —— 训练 15 个专家，并保存各专家在 LOCO 各折上的预测概率（`results/Expert_prob/seed_{seed}/{expert}/{center}.csv`）。
2. `evaluate_ensemble` —— 集成整体指标，输出 `ensemble_metrics.csv` 与 ROC / PR 曲线（`figures/`）。
3. `evaluate_experts` —— 单专家指标，输出 `expert_metrics.csv`。
4. `evaluate_ablation` —— 留一专家消融（leave-one-expert-out），输出 `leave_one_expert_out.csv`。
5. `scan_thresholds` —— 阈值扫描（0.30 – 0.80，步长 0.05），输出 `threshold_scan.csv`，并标注目标阈值 0.56。

> 若需更换专家组合、阈值或随机种子，直接修改 `Run_train_voting_center.py` 中的 `experts_config`、`threshold`、`base_seed`（或 `seed_list`）即可。

### 5.3 数据与脚本对应关系

为便于验证与复现，本仓库对三份输入做了区分处理：

- **`data/Example/`**：提供一份示例 `.fif`（`Example.fif`），对应 `data.csv` 中 `Dataset == "Example"` 的样本，用于验证 **Step 1（预处理）** 与 **Step 2（特征计算）** 两条流水线。
- **`data/{10,20,30}{start,mid}/feature/`**：已提供**全量七域特征表**（4 个中心 × 6 个时间窗），**无需重跑 Step 1 与 Step 2**，可直接执行 **Step 3（异质集成训练与评估）**。
- **运行 Step 3 前需删除 `data/data.csv` 中 `Dataset == "Example"` 的行**，否则示例样本会作为额外中心参与 Leave-One-Center-Out 划分，干扰评估结果。

按需选择两种运行路径：

| 目标 | 运行脚本 |
|------|----------|
| 验证预处理 / 特征计算流水线 | `Run_Data_Preprocess.py` → `Run_Compute_Feature.py` |
| 直接复现集成结果 | 删除 `data.csv` 中 Example 行 → `Run_train_voting_center.py` |

## 6. 评估指标

统一采用以下 11 项指标（见 `src/train/eval_utils.py`）：

`Accuracy`、`ROC_AUC`、`F1`、`Kappa`、`MCC`、`Precision`、`Recall`、`Specificity`、`NPV`、`AUC_PR`、`Balanced_Accuracy`

其中 `Balanced_Accuracy` 定义为 `(Recall + Specificity) / 2`。所有指标在 9 个随机种子 × 4 个测试中心上聚合，报告 **均值 ± 标准差**。

---

## 7. 关键设计原则

- **无泄露**：LOCO 划分下，特征选择、模型训练、阈值确定、专家池构造均只在训练中心完成，测试中心全程不可见。
- **覆盖优先于性能**：15 个专家的组合仅由“七域 / 5 选择器 / 6 分类器 / 6 时间窗全覆盖”规则决定，不依据任何性能指标筛选。
- **跨中心泛化**：以整个中心为单位留出，模拟真实临床中的跨中心部署场景。
- **概率缓存复用**：训练阶段只保存每个专家、每折、每个种子的预测概率；后续更换阈值、进行消融或亚组分析时无需重训。