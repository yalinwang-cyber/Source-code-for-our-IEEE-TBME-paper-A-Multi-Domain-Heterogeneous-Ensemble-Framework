"""
数据加载工具模块 / Data loading utility module.

提供 load_data() 函数读取 data.csv, 并对 EZ/NEZ 通道列表、标签、采样率等字段做类型解析。

Provides load_data() to read data.csv and parse fields such as the EZ/NEZ channel
lists, labels, and sampling rates.

依赖 / Dependencies: pandas
"""

import pandas as pd


def load_data():
    """
    读取 data/data.csv 并解析字段类型 / Read data/data.csv and parse field types.

    返回 / Returns:
        pd.DataFrame: 包含以下字段的患者元数据 / Patient metadata with fields:
            - Dataset        : 临床中心 / Clinical center
            - patient_name   : 患者编号 / Patient ID
            - sample_name    : 发作样本编号 / Seizure sample ID
            - orig_sfreq     : 原始采样率 / Original sampling rate
            - target_sfreq   : 目标采样率 / Target sampling rate
            - EZ             : 致痫区通道索引列表(已解析为 list) / EZ channel indices (list)
            - NEZ            : 非致痫区通道索引列表(已解析为 list) / NEZ channel indices (list)
            - isCured        : 标签(bool) / Label (bool)
            - Implant        : 植入模态(SEEG/ECoG) / Implant modality
            - start_time/end_time : 发作起止时间 / Seizure onset & offset
    """
    path = "data/data.csv"
    df = pd.read_csv(path, encoding='utf-8-sig')

    def parse_list(val):
        """将字符串形式的列表/数字串解析为 int 列表 / Parse a string list into a list of ints."""
        if isinstance(val, list):
            return val
        if isinstance(val, str):
            val = val.strip()
            if not val:
                return []
            # 形如 "[1, 2, 3]" 的字面量 / Literal like "[1, 2, 3]"
            if val.startswith('[') and val.endswith(']'):
                try:
                    import ast
                    return ast.literal_eval(val)
                except (ValueError, SyntaxError):
                    pass
            # 逗号或空格分隔的数字串 / Comma- or space-separated numbers
            if ',' in val:
                parts = val.split(',')
            else:
                parts = val.split()
            return [int(x.strip()) for x in parts if x.strip().isdigit()]
        return []

    # 解析 EZ / NEZ 通道列表 / Parse EZ / NEZ channel lists
    df['EZ'] = df['EZ'].apply(parse_list)
    df['NEZ'] = df['NEZ'].apply(parse_list)

    # 标签转为 bool / Convert label to bool
    if 'isCured' in df.columns:
        df['isCured'] = df['isCured'].astype(bool)

    # 目标采样率转为数值 / Convert target sampling rate to numeric
    if 'target_sfreq' in df.columns:
        df['target_sfreq'] = pd.to_numeric(df['target_sfreq'], errors='coerce')

    return df
