"""
滤波模块 / Filtering module.

提供三类 iEEG 滤波操作:
  - notch_filter      : 陷波滤波(去除 50/60 Hz 工频及其谐波)
  - bandpass_filter   : 带通滤波
  - bandsplit_filter  : 多频带分割(将信号按多个频带分别带通滤波并输出)

Provides three iEEG filtering operations:
  - notch_filter      : notch filter (remove 50/60 Hz line noise & harmonics)
  - bandpass_filter   : bandpass filter
  - bandsplit_filter  : multi-band split (bandpass each band and save separately)

依赖 / Dependencies: mne, tqdm
"""

import mne
from pathlib import Path
from tqdm import tqdm


def notch_filter(patient_data, input_path: str, output_path: str):
    """
    陷波滤波: 按中心去除 50 Hz 或 60 Hz 工频干扰及其谐波 /
    Notch filter: remove 50/60 Hz line noise and harmonics per center.

    参数 / Parameters:
        patient_data : DataFrame, 包含 sample_name 与 Dataset 列 / DataFrame with `sample_name`, `Dataset`.
        input_path   : str, 输入 .fif 目录 / Input directory.
        output_path  : str, 输出目录 / Output directory.
    """
    input_path = Path(input_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    # 不同中心的市电频率不同 / Mains frequency differs across centers
    freq_map = {
        'Example': 50,
        'LZUSH': 50,
        'CHFU': 50,
        'HUP': 60,
        'FMRS': 60
    }

    for _, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="Notch filtering"):
        file_path = input_path / f"{row['sample_name']}.fif"
        raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)

        dataset = row['Dataset']
        notch_freq = freq_map.get(dataset)

        # 取基频的 1~3 次谐波(需小于 Nyquist) / Take 1st–3rd harmonics (must be < Nyquist)
        nyquist = raw.info['sfreq'] / 2.0
        notch_freqs = [notch_freq * i for i in range(1, 4) if notch_freq * i < nyquist]

        for freq in notch_freqs:
            raw.notch_filter(freq, picks='eeg', verbose=False)
        raw.save(output_path / file_path.name, overwrite=True, verbose=False)
        raw.close()


def bandpass_filter(patient_data, input_path: str, output_path: str, l_freq: float, h_freq: float):
    """
    带通滤波 / Bandpass filter.

    参数 / Parameters:
        patient_data : DataFrame, 包含 sample_name 列 / DataFrame with `sample_name`.
        input_path   : str, 输入目录 / Input directory.
        output_path  : str, 输出目录 / Output directory.
        l_freq       : float, 低截止频率(Hz) / Lower cutoff (Hz).
        h_freq       : float, 高截止频率(Hz) / Upper cutoff (Hz).
    """
    input_path = Path(input_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    for _, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="Bandpass filtering"):
        file_path = input_path / f"{row['sample_name']}.fif"
        raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)
        raw.filter(l_freq=l_freq, h_freq=h_freq, picks='eeg', verbose=False)
        raw.save(output_path / file_path.name, overwrite=True, verbose=False)
        raw.close()


def bandsplit_filter(patient_data, input_path, output_path, bands):
    """
    多频带分割滤波: 将信号按多个频带分别带通并保存到各自子目录 /
    Multi-band split: bandpass the signal into multiple bands and save each to its own subfolder.

    参数 / Parameters:
        patient_data : DataFrame, 包含 sample_name 列 / DataFrame with `sample_name`.
        input_path   : str, 输入目录 / Input directory.
        output_path  : str, 输出目录(每个频带一个子目录) / Output dir (one subfolder per band).
        bands        : dict, {band_name: (l_freq, h_freq)} / Band definitions.
    """
    base_path = Path(input_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    # 为每个频带创建子目录 / Create a subfolder for each band
    for band_name in bands:
        (output_path / band_name).mkdir(exist_ok=True)

    for idx, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="Bandsplit filtering"):
        file_path = base_path / f"{row['sample_name']}.fif"

        raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)

        # 对每个频带复制原始数据并带通滤波 / Copy raw and bandpass-filter for each band
        for band_name, (l_freq, h_freq) in bands.items():
            raw_band = raw.copy()
            raw_band.filter(l_freq, h_freq, picks='eeg', verbose=False)

            out_path = output_path / band_name / file_path.name
            raw_band.save(out_path, overwrite=True, verbose=False)
        raw.close()
