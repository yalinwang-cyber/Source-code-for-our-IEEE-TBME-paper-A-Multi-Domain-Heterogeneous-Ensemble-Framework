"""
时间窗截取模块 / Time-window cropping module.

提供三种 iEEG 时间窗操作:
  - crop_start : 自发作起始向前截取指定时长
  - crop_mid   : 以发作中点为中心向两侧截取指定时长
  - resample   : 重采样至目标采样率

Provides three iEEG time-window operations:
  - crop_start : crop a fixed duration forward from seizure onset
  - crop_mid   : crop a fixed duration centered at the seizure midpoint
  - resample   : resample to a target sampling rate

依赖 / Dependencies: mne, tqdm
"""

import mne
from pathlib import Path
from tqdm import tqdm


def crop_start(patient_data, input_path: str, output_path: str, time: float):
    """
    自发作起始向前截取 `time` 秒 / Crop `time` seconds forward from seizure onset.

    参数 / Parameters:
        patient_data : DataFrame, 包含 sample_name 列 / DataFrame with `sample_name` column.
        input_path   : str, 原始 .fif 目录 / Directory of raw .fif files.
        output_path  : str, 截取后输出目录 / Output directory for cropped files.
        time         : float, 截取时长(秒) / Duration in seconds.
    """
    input_path = Path(input_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    for _, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="Cropping start"):
        file_path = input_path / f"{row['sample_name']}.fif"
        raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)
        raw_dur = raw.times[-1]

        # 从 0 秒(发作起始)开始截取 / Crop from t=0 (seizure onset)
        t_start = 0.0
        t_end = min(time, raw_dur)
        if t_end > t_start:
            raw.crop(tmin=t_start, tmax=t_end, include_tmax=True)
            out_path = output_path / f"{file_path.stem}.fif"
            raw.save(out_path, overwrite=True, verbose=False)
        raw.close()


def crop_mid(patient_data, input_path: str, output_path: str, time: float):
    """
    以发作中点为中心向两侧截取 `time` 秒 / Crop `time` seconds centered at seizure midpoint.

    参数 / Parameters:
        patient_data : DataFrame, 包含 sample_name 列 / DataFrame with `sample_name` column.
        input_path   : str, 原始 .fif 目录 / Directory of raw .fif files.
        output_path  : str, 截取后输出目录 / Output directory for cropped files.
        time         : float, 截取时长(秒) / Duration in seconds.
    """
    input_path = Path(input_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    for _, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="Cropping mid"):
        file_path = input_path / f"{row['sample_name']}.fif"
        raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)
        raw_dur = raw.times[-1]

        # 以中点为中心, 向两侧各取 time/2 / Center at midpoint, take time/2 on each side
        mid = raw_dur / 2.0
        t_start = max(0.0, mid - time / 2.0)
        t_end = min(raw_dur, t_start + time)
        if t_end > t_start:
            raw.crop(tmin=t_start, tmax=t_end, include_tmax=True)
            out_path = output_path / f"{file_path.stem}.fif"
            raw.save(out_path, overwrite=True, verbose=False)
        raw.close()


def resample(patient_data, input_path: str, output_path: str, resample_freq: float):
    """
    重采样至目标采样率 / Resample signals to a target sampling rate.

    参数 / Parameters:
        patient_data   : DataFrame, 包含 sample_name 列 / DataFrame with `sample_name` column.
        input_path     : str, 原始 .fif 目录 / Directory of raw .fif files.
        output_path    : str, 重采样后输出目录 / Output directory for resampled files.
        resample_freq  : float, 目标采样率(Hz) / Target sampling rate in Hz.
    """
    input_path = Path(input_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    for _, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="Resampling"):
        file_path = input_path / f"{row['sample_name']}.fif"
        raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)

        # 仅在采样率不一致时重采样, 否则直接复制 / Only resample if sfreq differs, otherwise copy as-is
        if raw.info['sfreq'] != resample_freq:
            raw.resample(sfreq=resample_freq, verbose=False)
            out_path = output_path / f"{file_path.stem}.fif"
            raw.save(out_path, overwrite=True, verbose=False)
        else:
            out_path = output_path / f"{file_path.stem}.fif"
            raw.save(out_path, overwrite=True, verbose=False)
        raw.close()
