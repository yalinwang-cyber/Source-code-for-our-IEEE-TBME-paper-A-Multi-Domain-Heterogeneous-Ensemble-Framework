"""
互信息(MI)特征选择器 / Mutual Information (MI) feature selector.

计算各特征与标签的互信息, 取 top-k。
Computes mutual information between each feature and the label, keeps top-k.

依赖 / Dependencies: numpy, scikit-learn
"""

import numpy as np
from sklearn.feature_selection import mutual_info_classif


def select_mutual_info(X_train, y_train, X_test=None, k=40, random_seed=42):
    """
    互信息特征筛选, 选择 top k 个特征 / Mutual-information feature selection, keep top-k.

    参数 / Parameters:
        X_train    : (n_train, n_features)
        y_train    : (n_train,)
        X_test     : (n_test, n_features) 或 None / or None
        k          : 保留特征数 / Number of features to keep.
        random_seed: 随机种子 / Random seed.
    返回 / Returns:
        X_train_sel, (X_test_sel,) selected_idx
    """
    n_feat = X_train.shape[1]
    k = min(k, n_feat)

    # 计算互信息得分
    scores = mutual_info_classif(X_train, y_train, random_state=random_seed)

    # 选择 top k 个特征
    selected_idx = np.argsort(scores)[-k:][::-1]
    selected_idx = np.sort(selected_idx)

    X_train_sel = X_train[:, selected_idx]

    if X_test is not None:
        X_test_sel = X_test[:, selected_idx]
        return X_train_sel, X_test_sel, selected_idx

    return X_train_sel, selected_idx