"""
L1 正则化特征选择器 / L1-regularized feature selector.

用 L1 逻辑回归的非零系数选择特征, 超过 k 个时取系数绝对值最大的前 k 个。
Selects features with non-zero coefficients from an L1 logistic regression;
if more than k survive, keeps the top-k by absolute coefficient.

依赖 / Dependencies: numpy, scikit-learn
"""

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=FutureWarning)

def select_l1(X_train, y_train, X_test=None, k=50, random_seed=42 , C=0.5):
    """
    L1 正则化特征筛选, 通过逻辑回归的非零系数选择特征 /
    L1-regularized feature selection via non-zero coefficients of logistic regression.

    参数 / Parameters:
        X_train      : (n_train, n_features)
        y_train      : (n_train,)
        X_test       : (n_test, n_features) 或 None / or None
        C            : L1 正则化强度的倒数, 越小越强 / Inverse of L1 strength (smaller = stronger).
        random_seed  : 随机种子 / Random seed.
        k            : 最大保留特征数 / Max number of features to keep.
    返回 / Returns:
        X_train_sel, (X_test_sel,) selected_idx
    """
    # 标准化
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)

    # L1逻辑回归
    l1_model = LogisticRegression(
        penalty='l1', C=C, solver='saga',
        max_iter=5000, random_state=random_seed,
        class_weight='balanced'
    )
    l1_model.fit(X_train_scaled, y_train)

    # 提取非零系数特征
    selected_idx = np.where(l1_model.coef_[0] != 0)[0]

    # 限制最大特征数
    if len(selected_idx) > k:
        coef_abs = np.abs(l1_model.coef_[0][selected_idx])
        top_idx = np.argsort(coef_abs)[-k:]
        selected_idx = selected_idx[top_idx]

    # 特征数过少时回退到全特征
    if len(selected_idx) < 2:
        selected_idx = np.arange(X_train.shape[1])

    X_train_sel = X_train[:, selected_idx]

    if X_test is not None:
        X_test_sel = X_test[:, selected_idx]
        return X_train_sel, X_test_sel, selected_idx

    return X_train_sel, selected_idx