"""
ANOVA F 检验特征选择器 / ANOVA F-test feature selector.

用 sklearn 的 SelectKBest + f_classif 选择与标签最相关的 top-k 特征。
Uses sklearn's SelectKBest with f_classif to pick the top-k features most related to the label.

依赖 / Dependencies: numpy, scikit-learn
"""

import numpy as np
from sklearn.feature_selection import SelectKBest, f_classif
import warnings
warnings.filterwarnings('ignore', category=RuntimeWarning)

def select_f_classif(X_train, y_train, X_test=None, k=40, random_seed=42):
    """
    ANOVA F 检验筛选 top k 个特征 / ANOVA F-test to select top-k features.

    参数 / Parameters:
        X_train : (n_train, n_features)
        y_train : (n_train,)
        X_test  : (n_test, n_features) 或 None / or None
        k       : 保留特征数 / Number of features to keep.
    返回 / Returns:
        X_train_sel, (X_test_sel,) selected_idx
    """
    n_feat = X_train.shape[1]
    k = min(k, n_feat)
    selector = SelectKBest(score_func=f_classif, k=k)
    selector.fit(X_train, y_train)
    X_train_sel = selector.transform(X_train)
    selected_idx = np.where(selector.get_support())[0]

    if X_test is not None:
        X_test_sel = selector.transform(X_test)
        return X_train_sel, X_test_sel, selected_idx
    return X_train_sel, selected_idx