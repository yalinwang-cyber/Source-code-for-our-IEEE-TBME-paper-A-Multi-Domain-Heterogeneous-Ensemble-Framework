"""
Boruta 特征选择器 / Boruta feature selector.

基于随机森林的 Boruta 全相关特征选择, 自动选择与标签显著相关的特征(不固定维度)。
Boruta all-relevant feature selection based on Random Forest; automatically selects
features significantly related to the label (dimension not fixed).

依赖 / Dependencies: numpy, scikit-learn, boruta
"""

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from boruta import BorutaPy
import warnings

from sklearn.exceptions import ConvergenceWarning
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=ConvergenceWarning)

def select_boruta(X_train, y_train, X_test=None, k=0, random_seed=42):
    """
    Boruta 特征筛选, 自动选择与标签显著相关的特征 /
    Boruta feature selection; auto-select features significantly related to the label.

    参数 / Parameters:
        X_train     : (n_train, n_features)
        y_train     : (n_train,)
        X_test      : (n_test, n_features) 或 None / or None
        random_seed : 随机种子 / Random seed.
    返回 / Returns:
        X_train_sel, (X_test_sel,) selected_idx
    """
    rf = RandomForestClassifier(
        n_estimators=100,
        max_depth=None,
        min_samples_leaf=5,
        random_state=random_seed,
        n_jobs=-1,
        class_weight='balanced'
    )
    boruta = BorutaPy(
        estimator=rf,
        n_estimators='auto',
        perc=100,
        random_state=random_seed
    )
    boruta.fit(X_train, y_train)

    selected_idx = np.where(boruta.support_)[0]
    n_selected = len(selected_idx)

    # 特征数过少时回退到全特征
    if n_selected < 2:
        selected_idx = np.arange(X_train.shape[1])
        n_selected = len(selected_idx)

    X_train_sel = X_train[:, selected_idx]

    if X_test is not None:
        X_test_sel = X_test[:, selected_idx]
        return X_train_sel, X_test_sel, selected_idx

    return X_train_sel, selected_idx