"""
mRMR(最小冗余最大相关)特征选择器 / mRMR (min-Redundancy Max-Relevance) feature selector.

先用互信息筛 top-2k, 再用皮尔逊相关去冗余选出 k 个特征。
First pre-filters top-2k by mutual information, then removes redundancy via
Pearson correlation to keep k features.

依赖 / Dependencies: numpy, scipy, scikit-learn
"""

import numpy as np
from scipy.stats import ConstantInputWarning
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import mutual_info_classif
import scipy.stats as stats
import warnings
warnings.filterwarnings('ignore', category=ConstantInputWarning)
warnings.filterwarnings('ignore', category=ConvergenceWarning)

def select_mrmr(X_train, y_train, X_test=None, k=50, random_seed=42):
    """
    简化版 mRMR 特征筛选: 先互信息筛选 top 2k, 再基于皮尔逊相关去冗余 /
    Simplified mRMR: pre-filter top-2k by MI, then de-redundantize by Pearson correlation.

    参数 / Parameters:
        X_train    : (n_train, n_features)
        y_train    : (n_train,)
        X_test     : (n_test, n_features) 或 None / or None
        k          : 保留特征数 / Number of features to keep.
        random_seed: 随机种子 / Random seed.
    返回 / Returns:
        X_train_sel, (X_test_sel,) selected_idx
    """
    n_feat = X_train.shape[1]
    k = min(k, n_feat)

    # 计算互信息
    mi = mutual_info_classif(X_train, y_train, random_state=random_seed)

    # 保留 top 2k 个特征
    top_n = min(2 * k, n_feat)
    top_idx = np.argsort(mi)[-top_n:][::-1]
    X_top = X_train[:, top_idx]

    # mRMR 选择
    selected = []
    remaining = list(range(X_top.shape[1]))

    for _ in range(min(k, X_top.shape[1])):
        if not selected:
            selected.append(remaining.pop(0))
        else:
            best_score = -np.inf
            best_idx = None
            for idx in remaining:
                corr_sum = 0
                for s in selected:
                    corr, _ = stats.pearsonr(X_top[:, idx], X_top[:, s])
                    corr_sum += abs(corr)
                avg_corr = corr_sum / len(selected)
                score = mi[top_idx[idx]] - avg_corr
                if score > best_score:
                    best_score = score
                    best_idx = idx
            if best_idx is not None:
                selected.append(best_idx)
                remaining.remove(best_idx)

    selected_idx = top_idx[selected]
    selected_idx = np.sort(selected_idx)

    X_train_sel = X_train[:, selected_idx]

    if X_test is not None:
        X_test_sel = X_test[:, selected_idx]
        return X_train_sel, X_test_sel, selected_idx

    return X_train_sel, selected_idx