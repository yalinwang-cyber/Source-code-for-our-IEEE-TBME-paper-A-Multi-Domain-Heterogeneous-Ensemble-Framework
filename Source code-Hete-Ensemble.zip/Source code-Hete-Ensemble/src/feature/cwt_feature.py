"""
连续小波变换(CWT)特征计算模块 / Continuous Wavelet Transform (CWT) feature module.

使用 Morlet 小波对信号做 8 尺度 CWT, 提取:
  - 每尺度幅度与相位的统计特征(均值/中位数/std/偏度/峰度/分位数/熵/样本熵等)
  - 全局频谱特征(总能量/质心/带宽/平坦度/滚降/峰值频率)
在 EZ / NEZ 组内取均值。

Uses the Morlet wavelet for 8-scale CWT and extracts:
  - per-scale amplitude & phase statistics (mean/median/std/skew/kurt/percentile/
    entropy/sample-entropy, ...)
  - global spectral features (total energy/centroid/bandwidth/flatness/rolloff/peak freq)
Averaged within the EZ / NEZ groups.

依赖 / Dependencies: numpy, pandas, pywt, scipy, joblib, mne, antropy, tqdm
"""

from pathlib import Path
import warnings
import numpy as np
import pandas as pd
import pywt
from scipy.stats import kurtosis, skew, entropy
from joblib import Parallel, delayed
from tqdm import tqdm
import mne
import antropy


def compute_cwt_scales(raw, f_min=0.5, f_max=125.0, wavelet='morl', num_scales=8):
    """根据频率范围计算 CWT 尺度与对应频率 / Compute CWT scales and frequencies from a frequency range."""
    fs = raw.info['sfreq']
    freqs = np.logspace(np.log10(f_min), np.log10(f_max), num_scales)
    scales = pywt.frequency2scale(wavelet, freqs / fs)
    return scales, freqs


def _circular_mean(phase):
    return np.angle(np.mean(np.exp(1j * phase)))


def _circular_std(phase):
    r = np.abs(np.mean(np.exp(1j * phase)))
    return np.sqrt(-2 * np.log(r)) if r > 0 else np.nan


def _circular_skewness(phase):
    if len(phase) == 0:
        return np.nan
    z = np.exp(1j * phase)
    mean_z = np.mean(z)
    m2 = np.mean(z ** 2) / (mean_z ** 2 + 1e-12)
    m3 = np.mean(z ** 3) / (mean_z ** 3 + 1e-12)
    return np.imag(m3) / (np.abs(m2) ** (1.5) + 1e-12)


def _circular_kurtosis(phase):
    if len(phase) == 0:
        return np.nan
    z = np.exp(1j * phase)
    mean_z = np.mean(z)
    m2 = np.mean(z ** 2) / (mean_z ** 2 + 1e-12)
    m4 = np.mean(z ** 4) / (mean_z ** 4 + 1e-12)
    return np.real(m4) / (np.abs(m2) ** 2 + 1e-12) - 3


def _safe_sample_entropy(signal, order=2, metric='chebyshev'):
    if len(signal) < 100:
        return np.nan
    try:
        return antropy.sample_entropy(signal, order=order, metric=metric)
    except Exception:
        return np.nan


def _safe_approximate_entropy(signal, order=2, metric='chebyshev'):
    if len(signal) < 100:
        return np.nan
    try:
        return antropy.approximate_entropy(signal, order=order, metric=metric)
    except Exception:
        return np.nan


def _compute_scale_features(mag, phase):
    """
    计算单个尺度上的幅度与相位统计特征 / Compute amplitude & phase statistics at one scale.
    返回包含幅度统计与相位统计(含循环统计)的特征向量 / Returns a vector of magnitude & phase (incl. circular) stats.
    """
    feats = []

    # ===== 幅度谱特征 =====
    feats.append(np.mean(mag))
    feats.append(np.median(mag))
    feats.append(np.std(mag, ddof=1))
    feats.append(skew(mag, bias=False))
    feats.append(kurtosis(mag, fisher=False, bias=False))
    feats.append(np.max(mag))
    feats.append(np.min(mag))
    p25, p75 = np.percentile(mag, [25, 75])
    feats.append(p25)
    feats.append(p75)

    hist, _ = np.histogram(mag, bins=20)
    hist = hist / (hist.sum() + 1e-12)
    feats.append(entropy(hist, base=2))
    feats.append(_safe_sample_entropy(mag))
    feats.append(_safe_approximate_entropy(mag))
    feats.append(np.sum(np.square(mag)))

    feats.append(np.mean(phase))
    feats.append(np.median(phase))
    feats.append(np.std(phase, ddof=1))
    feats.append(skew(phase, bias=False))
    feats.append(kurtosis(phase, fisher=False, bias=False))

    hist_phase, _ = np.histogram(phase, bins=20, range=(-np.pi, np.pi))
    hist_phase = hist_phase / (hist_phase.sum() + 1e-12)
    feats.append(entropy(hist_phase, base=2))

    feats.append(_circular_mean(phase))
    feats.append(_circular_std(phase))
    feats.append(_circular_skewness(phase))
    feats.append(_circular_kurtosis(phase))

    return np.array(feats, dtype=np.float64)


def compute_cwt_features_from_data(signal, fs, ch_idx, scales, freqs):
    """
    对单通道信号做 CWT 并提取逐尺度与全局特征 / Run CWT on a single channel and extract per-scale & global features.

    返回 / Returns:
        (final_feats, global_feats): 逐尺度特征向量与全局频谱特征向量。
    """
    coef, _ = pywt.cwt(signal, scales, 'morl', sampling_period=1 / fs)
    num_scales = coef.shape[0]

    mag_energies = np.sum(np.abs(coef) ** 2, axis=1)
    total_energy = np.sum(mag_energies) + 1e-12
    energy_dist = mag_energies / total_energy

    spectral_centroid = np.sum(freqs * energy_dist)
    spectral_bandwidth = np.sqrt(np.sum(((freqs - spectral_centroid) ** 2) * energy_dist))
    gmean = np.exp(np.mean(np.log(mag_energies + 1e-12)))
    amean = np.mean(mag_energies)
    spectral_flatness = gmean / (amean + 1e-12)
    cumsum_energy = np.cumsum(energy_dist)
    rolloff_idx = np.where(cumsum_energy >= 0.85)[0]
    spectral_rolloff = freqs[rolloff_idx[0]] if len(rolloff_idx) > 0 else freqs[-1]
    peak_freq_idx = int(np.argmax(mag_energies))
    peak_freq = freqs[peak_freq_idx]

    global_feats = np.array([
        total_energy, spectral_centroid, spectral_bandwidth,
        spectral_flatness, spectral_rolloff, peak_freq, peak_freq_idx
    ], dtype=np.float64)

    scale_features = []
    for i in range(num_scales):
        mag = np.abs(coef[i, :])
        phase = np.angle(coef[i, :])
        scale_features.append(_compute_scale_features(mag, phase))

    per_scale_feats = np.concatenate(scale_features)  # 24 * num_scales
    ratio_feats = mag_energies / total_energy  # num_scales
    final_feats = np.concatenate([per_scale_feats, ratio_feats])

    return final_feats, global_feats


def _aggregate_mean(ch_feat_list):
    if not ch_feat_list:
        return np.array([])
    arr = np.array(ch_feat_list)  # (n_ch, n_feats)
    mean_vec = np.nanmean(arr, axis=0)
    return np.nan_to_num(mean_vec, nan=0.0)


def compute_all_cwt_features(patient_data, base_path, output_path,
                             f_min=0.5, f_max=125.0, wavelet='morl', num_scales=8):
    """
    计算所有样本的 CWT 特征并保存为 cwt_feature.csv /
    Compute CWT features for all samples and save to cwt_feature.csv.

    参数 / Parameters:
        patient_data : DataFrame, 含 sample_name / isCured / EZ / NEZ 列。
        base_path    : 0.5–125 Hz 带通数据目录 / 0.5–125 Hz bandpass data dir.
        output_path  : 输出目录 / Output directory.
        f_min/f_max  : 频率范围 / Frequency range.
        wavelet      : 小波名, 默认 morl / Wavelet name, default morl.
        num_scales   : 尺度数, 默认 8 / Number of scales, default 8.
    """
    warnings.filterwarnings('ignore', message='.*does not conform to MNE naming conventions.*')
    base_path = Path(base_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    #first_file = base_path / patient_data.iloc[0]['sample_name']
    #first_file = f"{first_file}.fif"

    #if not first_file.exists():
    #    raise FileNotFoundError(f"第一个文件不存在: {first_file}")
    first_file = "data/iEEG/Example.fif"
    tmp_raw = mne.io.read_raw_fif(first_file, preload=False, verbose=False)
    scales, freqs = compute_cwt_scales(tmp_raw, f_min, f_max, wavelet, num_scales)
    tmp_raw.close()

    base_feat_names = [
        'mag_mean', 'mag_median', 'mag_std', 'mag_skewness', 'mag_kurtosis',
        'mag_max', 'mag_min', 'mag_percentile_25', 'mag_percentile_75',
        'mag_entropy', 'mag_sample_entropy', 'mag_approx_entropy', 'mag_energy',
        'phase_mean', 'phase_median', 'phase_std', 'phase_skewness', 'phase_kurtosis',
        'phase_entropy',
        'phase_circ_mean', 'phase_circ_std', 'phase_circ_skewness', 'phase_circ_kurtosis'
    ]

    n_base_per_scale = len(base_feat_names)
    n_feats_per_scale = n_base_per_scale + 1
    n_total_scale_feats = n_feats_per_scale * num_scales

    scale_names = [f"C{i}" for i in range(1, num_scales + 1)]

    per_scale_labels = []
    for group in ['EZ', 'NEZ']:
        for scale in scale_names:
            for name in base_feat_names:
                per_scale_labels.append(f"cwt_{group}_{scale}_{name}_mean")
            per_scale_labels.append(f"cwt_{group}_{scale}_mag_energy_ratio_mean")

    global_feat_names = [
        "total_energy", "spectral_centroid", "spectral_bandwidth",
        "spectral_flatness", "spectral_rolloff", "peak_frequency", "peak_frequency_index"
    ]
    global_labels = []
    for group in ['EZ', 'NEZ']:
        for name in global_feat_names:
            global_labels.append(f"cwt_{group}_global_{name}_mean")

    all_labels = per_scale_labels + global_labels

    all_rows = []
    for _, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="计算 CWT 特征"):
        file_path = base_path / f"{row['sample_name']}.fif"
        if not file_path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")

        raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)
        data = raw.get_data()
        fs = raw.info['sfreq']
        raw.close()

        n_ch = data.shape[0]
        ez_chs = [i for i in row['EZ'] if 0 <= i < n_ch]
        nez_chs = [i for i in row['NEZ'] if 0 <= i < n_ch]

        def _compute_channel_features(ch_idx):
            return compute_cwt_features_from_data(data[ch_idx, :], fs, ch_idx, scales, freqs)

        if ez_chs:
            res_ez = Parallel(n_jobs=-1)(delayed(_compute_channel_features)(ch) for ch in ez_chs)
            scale_ez = _aggregate_mean([r[0] for r in res_ez])
            global_ez = _aggregate_mean([r[1] for r in res_ez])
        else:
            scale_ez = np.zeros(n_total_scale_feats)
            global_ez = np.zeros(len(global_feat_names))

        if nez_chs:
            res_nez = Parallel(n_jobs=-1)(delayed(_compute_channel_features)(ch) for ch in nez_chs)
            scale_nez = _aggregate_mean([r[0] for r in res_nez])
            global_nez = _aggregate_mean([r[1] for r in res_nez])
        else:
            scale_nez = np.zeros(n_total_scale_feats)
            global_nez = np.zeros(len(global_feat_names))

        combined = np.concatenate([scale_ez, scale_nez, global_ez, global_nez])
        combined = np.nan_to_num(combined, nan=0.0)

        row_data = [row['sample_name'], row['isCured']] + combined.tolist()
        all_rows.append(row_data)

    columns = ['sample_name', 'isCured'] + all_labels
    df_features = pd.DataFrame(all_rows, columns=columns)

    csv_path = output_path / "cwt_feature.csv"
    df_features.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"CWT 特征已保存至: {csv_path}，共 {len(df_features)} 个样本，{len(all_labels)} 个特征。")
    return df_features