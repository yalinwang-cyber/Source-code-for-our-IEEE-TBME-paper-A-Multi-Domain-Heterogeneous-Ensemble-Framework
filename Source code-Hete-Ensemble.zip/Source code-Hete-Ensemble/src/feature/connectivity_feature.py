"""
功能连接特征计算模块 / Functional connectivity feature module.

基于 7 频带分割数据, 对 EZ / NEZ 两组通道分别计算 Coherence / PLV / wPLI 三种
功能连接指标, 并对连接矩阵值做统计聚合(mean/std/q75/iqr/skew)。

Based on the 7-band-split data, computes Coherence / PLV / wPLI for the EZ / NEZ
channel groups and aggregates the connectivity-matrix values with mean/std/q75/iqr/skew.

依赖 / Dependencies: numpy, pandas, mne, mne_connectivity, joblib, scipy, tqdm
"""

from pathlib import Path

import numpy as np
import pandas as pd
import mne
import mne_connectivity
from joblib import Parallel, delayed
from tqdm import tqdm
import warnings
from scipy.stats import skew
warnings.filterwarnings("ignore", category=RuntimeWarning)

def make_epochs_from_raw(raw, duration=5.0):
    """将连续信号切分为固定时长的 epochs / Slice a continuous signal into fixed-duration epochs."""
    total_duration = raw.times[-1]
    if total_duration < duration:
        duration = total_duration
    events = mne.make_fixed_length_events(raw, duration=duration)
    epochs = mne.Epochs(raw, events, tmin=0, tmax=duration,
                        baseline=None, preload=True, verbose=False)
    return epochs

def compute_connectivity_for_patient(row, base_path, bands, duration, methods, stats):
    """
    计算单个样本在所有频带 / 通道组上的功能连接特征 /
    Compute functional-connectivity features for one sample across all bands & groups.
    """
    patient_feats = []
    output_file = f"{row['sample_name']}.fif"

    for band_name, (l_f, h_f) in bands.items():
        band_file = base_path / band_name / output_file
        if not band_file.exists():
            raise FileNotFoundError(f"频段文件不存在: {band_file}")

        raw = mne.io.read_raw_fif(band_file, preload=True, verbose=False)
        epochs = make_epochs_from_raw(raw, duration)
        ch_names = epochs.ch_names
        n_ch = len(ch_names)

        for group_name, ch_indices in [('EZ', row['EZ']), ('NEZ', row['NEZ'])]:
            valid = [i for i in ch_indices if 0 <= i < n_ch]
            if len(valid) < 2:
                patient_feats.extend([0.0] * (len(methods) * len(stats)))
                continue

            data_array = epochs.get_data()[:, valid, :]
            unique_names = [f"ch_{i}" for i in range(len(valid))]
            info = mne.create_info(
                ch_names=unique_names,
                sfreq=epochs.info['sfreq'],
                ch_types='eeg'
            )
            sub_epochs = mne.EpochsArray(data_array, info, verbose=False)

            try:
                con_list = mne_connectivity.spectral_connectivity_epochs(
                    sub_epochs,
                    method=methods,
                    mode='multitaper',
                    fmin=l_f, fmax=h_f,
                    verbose=False,
                    n_jobs=1
                )
                for con_obj in con_list:
                    data = con_obj.get_data()
                    if data.size == 0:
                        patient_feats.extend([0.0] * len(stats))
                        continue
                    flat_vals = data.flatten()
                    if np.all(flat_vals == 0):
                        patient_feats.extend([0.0] * len(stats))
                        continue

                    mean_val = float(np.mean(flat_vals))
                    std_val = float(np.std(flat_vals, ddof=1))
                    q75_val = float(np.percentile(flat_vals, 75))
                    q25_val = float(np.percentile(flat_vals, 25))
                    iqr_val = q75_val - q25_val
                    skew_val = float(skew(flat_vals, bias=False)) if len(flat_vals) >= 3 else 0.0
                    patient_feats.extend([
                        mean_val, std_val, q75_val, iqr_val, skew_val
                    ])
            except Exception:
                patient_feats.extend([0.0] * (len(methods) * len(stats)))

        raw.close()

    return patient_feats

def compute_all_connectivity_features(patient_data, base_path, output_path,
                                      bands, duration=5.0, n_jobs=-1):
    """
    计算所有样本的功能连接特征并保存为 connectivity_feature.csv /
    Compute functional-connectivity features for all samples and save to connectivity_feature.csv.
    """
    base_path = Path(base_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    band_names = list(bands.keys())
    methods = ['coh', 'plv', 'wpli']
    stats = ['mean', 'std', 'q75', 'iqr', 'skew']

    results = Parallel(n_jobs=n_jobs)(
        delayed(compute_connectivity_for_patient)(row, base_path, bands, duration, methods, stats)
        for _, row in tqdm(patient_data.iterrows(), total=len(patient_data),
                           desc="计算连接性特征 (Coh/PLV/WPLI)")
    )

    labels = []
    for band in band_names:
        for group in ['EZ', 'NEZ']:
            for method in methods:
                for stat in stats:
                    labels.append(f"{method}_{group}_{band}_{stat}")

    columns = ['sample_name', 'isCured'] + labels
    all_rows = []
    for i, (_, row) in enumerate(patient_data.iterrows()):
        all_rows.append([row['sample_name'], row['isCured']] + results[i])

    df_features = pd.DataFrame(all_rows, columns=columns)
    df_features.to_csv(output_path / "connectivity_feature.csv",
                       index=False, encoding='utf-8-sig')
    print(f"连接性特征已保存至 {output_path / 'connectivity_feature.csv'}")
    print(f"共 {len(df_features)} 个样本，{len(labels)} 个特征。")