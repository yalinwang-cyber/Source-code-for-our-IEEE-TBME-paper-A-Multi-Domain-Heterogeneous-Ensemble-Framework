"""
图论特征计算模块 / Graph-theory feature module.

基于功能连接矩阵构建加权脑网络, 对 EZ / NEZ 两组通道分别计算:
  - 加权强度(strength)
  - 介数中心性(betweenness centrality)
  - 聚类系数(clustering coefficient)
覆盖 7 频带 × 3 种连接方法(coh/plv/wpli)。

Builds weighted brain networks from functional-connectivity matrices and computes,
for the EZ / NEZ groups: weighted strength, betweenness centrality, clustering
coefficient, over 7 bands × 3 connectivity methods (coh/plv/wpli).

依赖 / Dependencies: numpy, pandas, mne, mne_connectivity, networkx, joblib, tqdm
"""

from pathlib import Path
from itertools import combinations

import numpy as np
import pandas as pd
import mne
import mne_connectivity
import networkx as nx
from joblib import Parallel, delayed
from tqdm import tqdm
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning)


def make_epochs_from_raw(raw, duration=5.0):
    """将连续信号切分为固定时长的 epochs / Slice a continuous signal into fixed-duration epochs."""
    total_duration = raw.times[-1]
    if total_duration < duration:
        duration = total_duration
    events = mne.make_fixed_length_events(raw, duration=duration)
    epochs = mne.Epochs(raw, events, tmin=0, tmax=duration,
                        baseline=None, preload=True, verbose=False)
    return epochs


def _get_subset_epochs(epochs, ch_indices, group_label=''):
    """从 epochs 中抽取指定通道子集, 通道数不足 2 时返回 None /
    Extract a channel subset from epochs; return None if fewer than 2 channels."""
    n_ch = len(epochs.ch_names)
    valid = [i for i in ch_indices if 0 <= i < n_ch]
    if len(valid) < 2:
        return None

    data_array = epochs.get_data()[:, valid, :]

    unique_names = [f"{group_label}_idx_{i}" for i in valid]
    info = mne.create_info(
        ch_names=unique_names,
        sfreq=epochs.info['sfreq'],
        ch_types='eeg'
    )

    return mne.EpochsArray(data_array, info, verbose=False)


def _compute_all_graph_metrics(subset_epochs, methods, l_f, h_f):
    """
    计算一组通道的图论指标(强度/介数/聚类系数) /
    Compute graph metrics (strength/betweenness/clustering) for a channel group.
    """
    if subset_epochs is None:
        return [np.nan] * (len(methods) * 3)

    n_ch = len(subset_epochs.ch_names)
    pairs = list(combinations(range(n_ch), 2))
    from_idx = [p[0] for p in pairs]
    to_idx = [p[1] for p in pairs]
    indices = (np.array(from_idx), np.array(to_idx))

    con_list = mne_connectivity.spectral_connectivity_epochs(
        subset_epochs, method=methods, mode='multitaper',
        fmin=l_f, fmax=h_f, indices=indices, verbose=False, n_jobs=1
    )

    all_feats = []
    for con_obj in con_list:
        conn_mean = np.mean(con_obj.get_data(), axis=1)

        adj_weighted = np.zeros((n_ch, n_ch))
        for pair_idx, (i, j) in enumerate(pairs):
            val = conn_mean[pair_idx]
            adj_weighted[i, j] = val
            adj_weighted[j, i] = val

        G_weighted = nx.from_numpy_array(adj_weighted, create_using=nx.Graph())
        str_vals = dict(G_weighted.degree(weight='weight'))
        bet_vals = nx.betweenness_centrality(G_weighted, weight='weight')
        clustering_vals = nx.clustering(G_weighted, weight='weight')

        all_feats.extend([
            np.mean(list(str_vals.values())),
            np.mean(list(bet_vals.values())),
            np.mean(list(clustering_vals.values()))
        ])
    return all_feats


def _process_patient_graph(row, base_path, bands, duration, methods):
    patient_feats = []
    output_file = f"{row['sample_name']}.fif"
    ez_idx = row['EZ']
    nez_idx = row['NEZ']

    for band_name, (l_f, h_f) in bands.items():
        band_file = base_path / band_name / output_file
        raw = mne.io.read_raw_fif(band_file, preload=True, verbose=False)
        epochs = make_epochs_from_raw(raw, duration)

        epochs_ez = _get_subset_epochs(epochs, ez_idx, group_label='EZ')
        epochs_nez = _get_subset_epochs(epochs, nez_idx, group_label='NEZ')

        ez_feats = _compute_all_graph_metrics(epochs_ez, methods, l_f, h_f)
        nez_feats = _compute_all_graph_metrics(epochs_nez, methods, l_f, h_f)

        patient_feats.extend(ez_feats + nez_feats)
        raw.close()

    return [row['sample_name'], row['isCured']] + patient_feats


def compute_all_graph_features(patient_data, base_path, output_path,
                               bands, duration=5.0, n_jobs=-1,
                               methods=['coh', 'plv', 'wpli']):
    """
    计算所有样本的图论特征并保存为 graph_feature.csv /
    Compute graph-theory features for all samples and save to graph_feature.csv.
    """
    base_path = Path(base_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    tasks = (delayed(_process_patient_graph)(row, base_path, bands, duration, methods)
             for _, row in patient_data.iterrows())
    results = Parallel(n_jobs=n_jobs)(
        tqdm(tasks, total=len(patient_data), desc="并行计算图论特征")
    )

    columns = ['sample_name', 'isCured']
    metrics = ['str', 'bet', 'clust']
    groups = ['EZ', 'NEZ']
    for band in bands:
        for group in groups:
            for meth in methods:
                for metric in metrics:
                    columns.append(f"graph_{meth}_{group}_{band}_{metric}")
    df_features = pd.DataFrame(results, columns=columns)
    csv_path = output_path / "graph_feature.csv"
    df_features.to_csv(csv_path, index=False, encoding='utf-8-sig')