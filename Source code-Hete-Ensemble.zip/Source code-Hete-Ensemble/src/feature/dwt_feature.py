"""
离散小波变换(DWT)特征计算模块 / Discrete Wavelet Transform (DWT) feature module.

使用 Daubechies-4(db4) 小波对信号做多级分解, 对每个子带(detail/approximation)
提取 9 个统计量(abs_mean/median/rms/std/相邻比值/skew/kurt/energy/energy_ratio),
在 EZ / NEZ 组内取均值。

Uses the Daubechies-4 (db4) wavelet for multi-level decomposition and extracts
9 statistics per sub-band (abs_mean/median/rms/std/adjacent-ratio/skew/kurt/
energy/energy_ratio), averaged within the EZ / NEZ groups.

依赖 / Dependencies: numpy, pandas, pywt, scipy, mne, tqdm
"""

# src/feature_compute/dwt_feature.py
from pathlib import Path

import numpy as np
import pandas as pd
import pywt
from scipy.stats import kurtosis, skew
from tqdm import tqdm

import mne

def get_dwt_level(fs, target_low=4.0):
    """根据采样率与最低目标频率估计 DWT 分解层数 / Estimate DWT decomposition level from fs and target low freq."""
    return int(np.ceil(np.log2(fs / target_low))) - 1

def compute_dwt_features(coeffs):
    """
    从 DWT 系数中提取每个子带的统计特征 / Extract per-subband statistics from DWT coefficients.

    参数 / Parameters:
        coeffs : pywt.wavedec 的输出, [cA_n, cD_n, ..., cD_1] / Output of pywt.wavedec.
    返回 / Returns:
        list: 展平后的子带统计特征 / Flattened subband statistics.
    """
    details = coeffs[:0:-1]
    approx = [coeffs[0]]
    subbands = details + approx

    abs_means = []
    features = []

    energies = []
    for coeff in subbands:
        c = np.asarray(coeff).flatten()
        energies.append(np.sum(np.square(c)))

    total_energy = sum(energies) + 1e-12

    for idx, coeff in enumerate(subbands):
        c = np.asarray(coeff).flatten()
        abs_mean = np.mean(np.abs(c))
        median   = np.median(c)
        rms      = np.sqrt(np.mean(np.square(c)))
        std      = np.std(c, ddof=1)
        skew_val = skew(c, bias=False)
        kurt_val = kurtosis(c, fisher=False, bias=False)

        abs_means.append(abs_mean)

        ratio = abs_mean / (abs_means[idx-1] + 1e-12) if idx > 0 else 1.0

        energy = energies[idx]
        energy_ratio = energy / total_energy

        features.extend([abs_mean, median, rms, std, ratio, skew_val, kurt_val,
                         energy, energy_ratio])

    return features

def compute_all_dwt_features(patient_data, base_path, output_path, wavelet='db4'):
    """
    计算所有样本的 DWT 特征并保存为 dwt_feature.csv /
    Compute DWT features for all samples and save to dwt_feature.csv.

    参数 / Parameters:
        patient_data : DataFrame, 含 sample_name / isCured / EZ / NEZ 列。
        base_path    : 0.5–125 Hz 带通数据目录 / 0.5–125 Hz bandpass data dir.
        output_path  : 输出目录 / Output directory.
        wavelet      : 小波名, 默认 db4 / Wavelet name, default db4.
    """
    base_path = Path(base_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    target_sfreq = 512
    level = get_dwt_level(target_sfreq, target_low=4.0)

    dwt_feature_names = ["abs_mean", "median", "rms", "std", "adjacent_abs_mean_ratio", "skewness", "kurtosis", "energy", "energy_ratio"]

    subband_names = [f"D{i}" for i in range(1, level + 1)] + [f"A{level}"]
    feature_labels = []
    for sub in subband_names:
        for group in ['EZ', 'NEZ']:
            for feat in dwt_feature_names:
                feature_labels.append(f"dwt_{group}_{sub}_{feat}")

    all_rows = []
    for idx, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="计算 DWT 特征"):
        file_path = base_path / f"{row['sample_name']}.fif"
        if not file_path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")

        raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)

        raw.resample(target_sfreq, npad='auto')

        ez_chs = row['EZ']
        nez_chs = row['NEZ']
        n_ch = len(raw.ch_names)

        ch_dict = {}
        for ch_idx in range(n_ch):
            data, _ = raw.get_data(picks=ch_idx, return_times=True)
            signal = data.flatten()
            coeffs = pywt.wavedec(signal, wavelet, level=level)
            ch_dict[ch_idx] = coeffs
        raw.close()

        if ez_chs:
            feats_ez = np.mean([compute_dwt_features(ch_dict[ch]) for ch in ez_chs], axis=0)
        else:
            feats_ez = np.zeros(len(feature_labels) // 2)

        if nez_chs:
            feats_nez = np.mean([compute_dwt_features(ch_dict[ch]) for ch in nez_chs], axis=0)
        else:
            feats_nez = np.zeros(len(feature_labels) // 2)

        if isinstance(feats_ez, np.ndarray):
            feats_ez = feats_ez.tolist()
        if isinstance(feats_nez, np.ndarray):
            feats_nez = feats_nez.tolist()

        row_data = [row['sample_name'], row['isCured']] + feats_ez + feats_nez
        all_rows.append(row_data)

    columns = ['sample_name', 'isCured'] + feature_labels
    df_features = pd.DataFrame(all_rows, columns=columns)
    csv_path = output_path / "dwt_feature.csv"
    df_features.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"DWT 特征已保存至: {csv_path}")