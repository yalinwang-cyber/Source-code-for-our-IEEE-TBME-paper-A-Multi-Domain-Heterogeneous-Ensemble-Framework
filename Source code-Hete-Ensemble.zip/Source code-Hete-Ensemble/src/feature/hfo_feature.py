"""
高频振荡(HFO)特征计算模块 / High-Frequency Oscillation (HFO) feature module.

基于 80–500 Hz 带通数据, 用 Hilbert 包络法检测 Ripple 与 Fast Ripple 事件,
对 EZ / NEZ 两组通道分别聚合事件发生率与事件属性(强度/最大包络等)的统计量。

Based on the 80–500 Hz bandpass data, detects Ripple and Fast Ripple events via the
Hilbert-envelope method and aggregates event rates and event attributes (strength,
max envelope, ...) for the EZ / NEZ channel groups.

依赖 / Dependencies: mne, numpy, pandas, scipy, joblib, tqdm
"""

from src.feature.HFOdetection_Hilbert import HFODetector_Hilbert
import mne
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=RuntimeWarning)
from pathlib import Path
from scipy import signal
from scipy.ndimage import binary_opening
from joblib import Parallel, delayed
from tqdm import tqdm


def _aggregate_channel_rates(rates, ch_indices):
    """对指定通道的事件发生率做统计聚合 / Aggregate event rates of selected channels."""
    if not ch_indices:
        return {stat: 0.0 for stat in ['mean', 'std', 'max', 'min', 'median']}
    vals = rates[ch_indices]
    return {
        'mean': float(np.mean(vals)),
        'std': float(np.std(vals, ddof=1)),
        'max': float(np.max(vals)),
        'min': float(np.min(vals)),
        'median': float(np.median(vals))
    }


def _aggregate_event_features(events_df, ch_indices, feature_cols):
    if events_df.empty or not ch_indices:
        return {(feat, stat): 0.0 for feat in feature_cols for stat in ['mean', 'std', 'max', 'min', 'median']}

    mask = events_df['ChannelIdx'].isin(ch_indices)
    sub = events_df.loc[mask, feature_cols]
    if sub.empty:
        return {(feat, stat): 0.0 for feat in feature_cols for stat in ['mean', 'std', 'max', 'min', 'median']}

    result = {}
    for feat in feature_cols:
        vals = sub[feat].values.astype(float)
        if len(vals) == 0:
            result[(feat, 'mean')] = 0.0
            result[(feat, 'std')] = 0.0
            result[(feat, 'max')] = 0.0
            result[(feat, 'min')] = 0.0
            result[(feat, 'median')] = 0.0
        else:
            result[(feat, 'mean')] = float(np.mean(vals))
            result[(feat, 'std')] = float(np.std(vals, ddof=1))
            result[(feat, 'max')] = float(np.max(vals))
            result[(feat, 'min')] = float(np.min(vals))
            result[(feat, 'median')] = float(np.median(vals))
    return result

def _process_one_sample(row, base_path):
    sample_name = row['sample_name']
    file_path = Path(base_path) / f"{row['sample_name']}.fif"
    if not file_path.exists():
        raise FileNotFoundError(f"HFO 输入文件不存在: {file_path}")

    raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)

    ds = row['Dataset']
    if ds in ("LZU", "FDU"):
        base_freq = 50.0
    elif ds in ("DS003029", "DS004100"):
        base_freq = 60.0
    else:
        base_freq = None

    if base_freq is not None:
        nyquist = raw.info['sfreq'] / 2.0
        notch_freqs = [base_freq * i for i in range(1, 4) if base_freq * i < nyquist]
        for freq in notch_freqs:
            raw.notch_filter(freq, picks='eeg', verbose=False)

    data = raw.get_data()
    sfreq = raw.info['sfreq']
    raw.close()

    data = data.T

    RippleRate, FastRippleRate, Ripples, FastRipples = HFODetector_Hilbert(data, sfreq)

    ripples_df = pd.DataFrame(Ripples, columns=['ChannelIdx', 'Freq', 'Start', 'Duration',
                                                'Strength', 'MaxEnvelope', 'MinNB', 'MaxDiff', 'SubEvents'])
    fastripples_df = pd.DataFrame(FastRipples, columns=['ChannelIdx', 'Freq', 'Start', 'Duration',
                                                        'Strength', 'MaxEnvelope', 'MinNB', 'MaxDiff', 'SubEvents'])

    n_ch = data.shape[1]

    ez_idx = row['EZ'] if isinstance(row['EZ'], list) else []
    nez_idx = row['NEZ'] if isinstance(row['NEZ'], list) else []
    ez_idx = [i for i in ez_idx if 0 <= i < n_ch]
    nez_idx = [i for i in nez_idx if 0 <= i < n_ch]

    groups = [('EZ', ez_idx), ('NEZ', nez_idx)]

    types = [('Ripple', RippleRate, ripples_df),
             ('FastRipple', FastRippleRate, fastripples_df)]

    feat_dict = {}

    event_feat_cols = ['Strength', 'MaxEnvelope', 'MinNB', 'MaxDiff']

    for group_name, ch_indices in groups:
        for type_name, rate_arr, events_df in types:

            rate_stats = _aggregate_channel_rates(rate_arr, ch_indices)
            for stat, val in rate_stats.items():
                key = f"hfo_{group_name}_{type_name}_Rate_{stat}"
                feat_dict[key] = val

            event_stats = _aggregate_event_features(events_df, ch_indices, event_feat_cols)
            for (feat, stat), val in event_stats.items():
                key = f"hfo_{group_name}_{type_name}_{feat}_{stat}"
                feat_dict[key] = val

    feat_dict['sample_name'] = sample_name
    feat_dict['isCured'] = row['isCured']

    return feat_dict

def compute_all_hfo_features(patient_data, base_path, output_path, n_jobs = -1):
    """
    计算所有样本的 HFO 特征并保存为 hfo_feature.csv /
    Compute HFO features for all samples and save to hfo_feature.csv.
    """
    base_path = Path(base_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    results = Parallel(n_jobs=n_jobs)(
        delayed(_process_one_sample)(row, base_path)
        for _, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="计算 HFO 特征")
    )

    df_out = pd.DataFrame(results)

    if len(df_out) != len(patient_data):
        print(f"警告: 成功处理的样本数 ({len(df_out)}) 与 patient_data ({len(patient_data)}) 不一致。")

    sample_col = 'sample_name'
    target_col = 'isCured'
    if sample_col not in df_out.columns or target_col not in df_out.columns:
        raise ValueError("结果 DataFrame 缺少 sample_name 或 isCured 列")

    df_out = df_out.set_index('sample_name').reindex(patient_data['sample_name']).reset_index()

    feature_cols = [c for c in df_out.columns if c not in [sample_col, target_col]]
    final_cols = [sample_col, target_col] + sorted(feature_cols)
    df_out = df_out[final_cols]

    csv_path = output_path / 'hfo_feature.csv'
    df_out.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"HFO 特征已保存至 {csv_path}，共 {len(df_out)} 个样本，{len(final_cols) - 2} 个特征。")

    return df_out