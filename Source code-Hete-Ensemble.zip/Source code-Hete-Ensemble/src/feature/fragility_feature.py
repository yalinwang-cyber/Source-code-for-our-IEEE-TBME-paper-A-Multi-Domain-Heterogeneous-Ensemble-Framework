"""
神经脆性(Neural Fragility)特征计算模块 / Neural Fragility feature module.

基于 0.5–125 Hz 带通数据, 用线性状态转移模型估计神经脆性矩阵, 并提取三层特征:
  - Layer 1: 通道平均脆性的组内统计量(mean/std/skew/max/min)
  - Layer 2: 状态转移矩阵的谱特征(谱半径/特征值/条件数)
  - Layer 3: 滑窗脆性时间序列的趋势与复杂度(slope/R2/CV/entropy)
覆盖 3 种窗口 × 5 组 (sigma, omega) 参数, 共 390 维。

Based on the 0.5–125 Hz bandpass data, estimates a neural-fragility matrix via a
linear state-transition model and extracts 3 layers of features:
  - Layer 1: group statistics of mean channel fragility
  - Layer 2: spectral features of state-transition matrices
  - Layer 3: trend & complexity of sliding-window fragility time series
Covering 3 windows × 5 (sigma, omega) parameter pairs, 390 dims in total.

依赖 / Dependencies: numpy, pandas, mne, joblib, scipy, antropy, tqdm
"""

from pathlib import Path
import numpy as np
import pandas as pd
import mne
from joblib import Parallel, delayed
from tqdm import tqdm
from scipy.stats import skew, linregress
import antropy
import scipy.signal as signal

from src.feature.neural_fragility import get_neural_fragility

# 滑窗大小与模型参数组合 / Sliding-window sizes & model parameter pairs
WINDOW_SIZES = [250, 500, 1000]
PARAM_PAIRS = [
    (0.05, 0.0),
    (0.1, 0.3),
    (0.1, 0.6),
    (0.3, 0.0),
    (0.5, 0.2)
]

def safe_sample_entropy(signal, order=2, metric='chebyshev'):
    """安全计算样本熵, 异常时返回 nan / Safely compute sample entropy; return nan on failure."""
    if len(signal) < 10:
        return np.nan
    try:
        return antropy.sample_entropy(signal, order=order, metric=metric)
    except:
        return np.nan


def compute_temporal_features_for_channel(time_series):
    n = len(time_series)
    if n < 3:
        return np.nan, np.nan, np.nan, np.nan

    x = np.arange(n)
    slope, intercept, r_value, p_value, std_err = linregress(x, time_series)
    r2 = r_value ** 2 if not np.isnan(r_value) else np.nan

    mean_val = np.mean(time_series)
    std_val = np.std(time_series, ddof=1)
    cv = std_val / mean_val if abs(mean_val) > 1e-8 else 0.0

    entropy = safe_sample_entropy(time_series)

    return slope, r2, cv, entropy


def aggregate_group_stats(values, stats_list=['mean', 'std', 'skew', 'max', 'min']):

    if len(values) == 0:
        return {stat: 0.0 for stat in stats_list}
    arr = np.array(values)

    result = {}
    if 'mean' in stats_list:
        result['mean'] = np.nanmean(arr)
    if 'std' in stats_list:
        result['std'] = np.nanstd(arr, ddof=1)
    if 'skew' in stats_list:
        result['skew'] = skew(arr, nan_policy='omit') if len(arr) > 1 else 0.0
    if 'max' in stats_list:
        result['max'] = np.nanmax(arr)
    if 'min' in stats_list:
        result['min'] = np.nanmin(arr)
    # 将NaN替换为0
    for k in result:
        if np.isnan(result[k]):
            result[k] = 0.0
    return result


def compute_spectral_features(A_matrices):

    if not A_matrices:
        return {f: 0.0 for f in ['spectral_radius_mean', 'spectral_radius_std',
                                 'eig_real_mean', 'eig_real_std',
                                 'eig_imag_abs_mean', 'condition_number_mean']}

    spectral_radii = []
    all_eig_real = []
    all_eig_imag_abs = []
    cond_numbers = []

    for A in A_matrices:
        eigvals = np.linalg.eigvals(A)
        spectral_radii.append(np.max(np.abs(eigvals)))
        all_eig_real.extend(np.real(eigvals))
        all_eig_imag_abs.extend(np.abs(np.imag(eigvals)))
        # 条件数
        try:
            cond = np.linalg.cond(A)
        except:
            cond = 1e6
        cond_numbers.append(cond)

    result = {
        'spectral_radius_mean': np.nanmean(spectral_radii),
        'spectral_radius_std': np.nanstd(spectral_radii, ddof=1),
        'eig_real_mean': np.nanmean(all_eig_real),
        'eig_real_std': np.nanstd(all_eig_real, ddof=1),
        'eig_imag_abs_mean': np.nanmean(all_eig_imag_abs),
        'condition_number_mean': np.nanmean(cond_numbers)
    }
    for k in result:
        if np.isnan(result[k]):
            result[k] = 0.0
    return result


def process_one_sample(row, base_path, detrend=True, demean=True, notch_50hz=False):
    file_path = Path(base_path) / f"{row['sample_name']}.fif"
    raw = mne.io.read_raw_fif(file_path, preload=True, verbose=False)
    data = raw.get_data()
    fs = raw.info['sfreq']
    raw.close()

    if detrend:
        data = signal.detrend(data, axis=1, type='linear')
    if demean:
        data = data - np.mean(data, axis=1, keepdims=True)

    n_ch = data.shape[0]
    ez_idx = [i for i in row['EZ'] if 0 <= i < n_ch]
    nez_idx = [i for i in row['NEZ'] if 0 <= i < n_ch]

    all_feats = []

    for win_size in WINDOW_SIZES:
        for sigma, omega in PARAM_PAIRS:
            result_dict = get_neural_fragility(data, sigma, omega, return_all=True)
            frag_mat = result_dict['fragility_matrix']  # (n_ch, n_windows)
            A_list = result_dict['A_matrices']  # list of (n_ch, n_ch)
            window_vecs = result_dict['window_fragility_vectors']  # list of (n_ch,)

            channel_mean_frag = np.mean(frag_mat, axis=1)
            ez_stats = aggregate_group_stats(channel_mean_frag[ez_idx] if ez_idx else [])
            nez_stats = aggregate_group_stats(channel_mean_frag[nez_idx] if nez_idx else [])
            for group_name, stats_dict in [('EZ', ez_stats), ('NEZ', nez_stats)]:
                for stat_name in ['mean', 'std', 'skew', 'max', 'min']:
                    all_feats.append(stats_dict.get(stat_name, 0.0))

            spec = compute_spectral_features(A_list)
            for key in ['spectral_radius_mean', 'spectral_radius_std',
                        'eig_real_mean', 'eig_real_std',
                        'eig_imag_abs_mean', 'condition_number_mean']:
                all_feats.append(spec.get(key, 0.0))

            n_windows = len(window_vecs)
            if n_windows >= 3:
                ch_time_series = np.array(window_vecs).T
                slopes, r2s, cvs, entropies = [], [], [], []
                for ch in range(n_ch):
                    slope, r2, cv, entropy = compute_temporal_features_for_channel(ch_time_series[ch, :])
                    slopes.append(slope);
                    r2s.append(r2);
                    cvs.append(cv);
                    entropies.append(entropy)
                for group_indices in [ez_idx, nez_idx]:
                    if group_indices:
                        group_slopes = [slopes[i] for i in group_indices if i < n_ch]
                        group_r2s = [r2s[i] for i in group_indices if i < n_ch]
                        group_cvs = [cvs[i] for i in group_indices if i < n_ch]
                        group_entropies = [entropies[i] for i in group_indices if i < n_ch]
                    else:
                        group_slopes = group_r2s = group_cvs = group_entropies = []

                    all_feats.extend([
                        np.nanmean(group_slopes) if group_slopes else 0.0,
                        np.nanstd(group_slopes, ddof=1) if len(group_slopes) > 1 else 0.0,
                        np.nanmean(group_r2s) if group_r2s else 0.0,
                        np.nanmean(group_cvs) if group_cvs else 0.0,
                        np.nanmean(group_entropies) if group_entropies else 0.0,
                    ])
            else:
                all_feats.extend([0.0] * 10)

            del result_dict, frag_mat, A_list, window_vecs

    all_feats = np.nan_to_num(all_feats, nan=0.0)
    return row['sample_name'], row['isCured'], all_feats

def compute_all_fragility_features(patient_data, base_path, output_path, n_jobs=-1):
    """
    计算所有样本的神经脆性特征并保存为 fragility_feature.csv /
    Compute neural-fragility features for all samples and save to fragility_feature.csv.
    """

    base_path = Path(base_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    tasks = [delayed(process_one_sample)(row, base_path) for _, row in patient_data.iterrows()]

    results = Parallel(n_jobs=n_jobs)(
        tqdm(tasks, total=len(patient_data), desc="计算神经脆弱性特征")
    )

    sample_names = [r[0] for r in results]
    isCured = [r[1] for r in results]
    feat_arrays = [r[2] for r in results]

    layer1_labels = []
    for win_size in WINDOW_SIZES:
        for sigma, omega in PARAM_PAIRS:
            for group in ['EZ', 'NEZ']:
                for stat in ['mean', 'std', 'skew', 'max', 'min']:
                    layer1_labels.append(
                        f"frag_S_win{win_size}_s{sigma:.2f}_o{omega:.2f}_{group}_{stat}"
                    )

    layer2_labels = []
    for win_size in WINDOW_SIZES:
        for sigma, omega in PARAM_PAIRS:
            for metric in ['spectral_radius_mean', 'spectral_radius_std',
                           'eig_real_mean', 'eig_real_std',
                           'eig_imag_abs_mean', 'condition_number_mean']:
                layer2_labels.append(
                    f"frag_A_win{win_size}_s{sigma:.2f}_o{omega:.2f}_{metric}"
                )

    layer3_labels = []
    for win_size in WINDOW_SIZES:
        for sigma, omega in PARAM_PAIRS:
            for group in ['EZ', 'NEZ']:
                for metric in ['slope_mean', 'slope_std', 'trend_r2_mean', 'cv_mean', 'entropy_mean']:
                    layer3_labels.append(
                        f"frag_T_win{win_size}_s{sigma:.2f}_o{omega:.2f}_{group}_{metric}"
                    )

    all_labels = layer1_labels + layer2_labels + layer3_labels
    expected_dim = 150 + 90 + 150  # 390
    assert len(all_labels) == expected_dim, f"标签数量 {len(all_labels)} 不等于预期 {expected_dim}"

    rows = []
    for name, cured, feats in zip(sample_names, isCured, feat_arrays):

        if len(feats) != expected_dim:
            print(f"警告: 样本 {name} 特征长度 {len(feats)} 不等于预期 {expected_dim}，将截断/填充")
            if len(feats) > expected_dim:
                feats = feats[:expected_dim]
            else:
                feats = np.pad(feats, (0, expected_dim - len(feats)), constant_values=0)
        rows.append([name, cured] + feats.tolist())

    columns = ['sample_name', 'isCured'] + all_labels
    df = pd.DataFrame(rows, columns=columns)

    csv_path = output_path / 'fragility_feature.csv'
    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"神经脆弱性特征已保存至 {csv_path}，共 {len(df)} 个样本，{len(all_labels)} 个特征。")

    return df