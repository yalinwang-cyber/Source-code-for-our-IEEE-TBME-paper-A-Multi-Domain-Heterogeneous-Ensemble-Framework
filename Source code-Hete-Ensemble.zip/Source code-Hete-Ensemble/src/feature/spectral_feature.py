"""
频谱特征计算模块 / Spectral feature extraction module.

基于 7 频带分割后的信号, 对 EZ / NEZ 两组通道分别提取 10 个时域统计量
(mean/std/ptp/var/rms/min/max/skew/kurt/energy), 再在组内做 mean/std 聚合,
并加入频带间能量/均值比值特征。

Based on the 7-band-split signals, extracts 10 time-domain statistics per channel
(mean/std/ptp/var/rms/min/max/skew/kurt/energy) for the EZ / NEZ groups, aggregates
them with mean/std, and adds inter-band energy/mean ratios.

依赖 / Dependencies: numpy, pandas, scipy, mne, tqdm
"""

from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import kurtosis, skew
from tqdm import tqdm
import mne
from itertools import combinations

def _compute_channel_features(signal):
    """
    计算单通道的 10 个时域统计量 / Compute 10 time-domain statistics for one channel.
    返回顺序 / Order: mean, std, ptp, var, rms, min, max, skew, kurt, energy
    """
    mean_val = np.mean(signal)
    std_val = np.std(signal, ddof=1)
    ptp_val = np.ptp(signal)
    var_val = np.var(signal, ddof=1)
    rms_val = np.sqrt(np.mean(np.square(signal)))
    min_val = np.min(signal)
    max_val = np.max(signal)
    skew_val = skew(signal, bias=False)
    kurt_val = kurtosis(signal, fisher=False, bias=False)
    energy = np.sum(np.square(signal))
    return np.array([mean_val, std_val, ptp_val, var_val, rms_val,
                     min_val, max_val, skew_val, kurt_val, energy])


def _aggregate_features(feature_matrix, ch_indices, stats):
    """
    对指定通道组的特征矩阵按列做统计聚合 / Aggregate the feature matrix of a channel group column-wise.

    参数 / Parameters:
        feature_matrix : (n_ch, 10) 每通道 10 个统计量 / (n_ch, 10) stats per channel.
        ch_indices     : 该组的通道索引 / Channel indices of this group.
        stats          : 聚合方式列表, 如 ['mean','std'] / Aggregation methods.
    返回 / Returns:
        np.ndarray: (10 * len(stats),) 展平后的聚合特征 / Flattened aggregated features.
    """
    if not ch_indices or len(ch_indices) == 0:
        return np.zeros(len(stats) * 10)
    sub = feature_matrix[ch_indices, :]  # (n_ch, 10)

    stat_values = {}
    for stat_func in stats:
        if stat_func == 'mean':
            stat_values['mean'] = np.mean(sub, axis=0)
        elif stat_func == 'std':
            stat_values['std'] = np.std(sub, axis=0, ddof=1)
        elif stat_func == 'median':
            stat_values['median'] = np.median(sub, axis=0)
        elif stat_func == 'max':
            stat_values['max'] = np.max(sub, axis=0)
        elif stat_func == 'min':
            stat_values['min'] = np.min(sub, axis=0)
        else:
            raise ValueError(f"Unknown stat: {stat_func}")

    results = []
    for feat_idx in range(10):
        for stat_func in stats:
            results.append(stat_values[stat_func][feat_idx])
    return np.array(results)


def compute_all_spectral_features(patient_data, base_path, output_path, band_names):
    """
    计算所有样本的频谱特征并保存为 spectral_feature.csv /
    Compute spectral features for all samples and save to spectral_feature.csv.

    参数 / Parameters:
        patient_data : DataFrame, 含 sample_name / isCured / EZ / NEZ 列。
        base_path    : 7 频带分割数据所在目录(含各频带子目录) / 7-band split data dir.
        output_path  : 输出目录 / Output directory.
        band_names   : 频带名称列表 / List of band names.
    """

    base_path = Path(base_path)
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)

    spectral_feature_names = ["mean", "std", "peak_to_peak", "variance", "rms",
                              "min", "max", "skewness", "kurtosis", "energy"]
    stats = ['mean', 'std']

    feature_labels = []
    for band in band_names:
        for group in ['EZ', 'NEZ']:
            for feat in spectral_feature_names:
                for stat in stats:
                    feature_labels.append(f"spectral_{group}_{band}_{feat}_{stat}")

    ratio_labels = []
    for group in ['EZ', 'NEZ']:
        for band1, band2 in combinations(band_names, 2):
            ratio_labels.append(f"spectral_{group}_energy_ratio_{band1}_{band2}")
            ratio_labels.append(f"spectral_{group}_mean_ratio_{band1}_{band2}")

    full_labels = feature_labels + ratio_labels
    all_rows = []

    for idx, row in tqdm(patient_data.iterrows(), total=len(patient_data), desc="计算频谱特征"):
        band_agg_means = {band: {'EZ': np.zeros(10), 'NEZ': np.zeros(10)} for band in band_names}
        patient_feats = []

        for band_name in band_names:
            band_file = base_path / band_name / f"{row['sample_name']}.fif"
            if not band_file.exists():
                raise FileNotFoundError(f"频段文件不存在: {band_file}")

            raw_band = mne.io.read_raw_fif(band_file, preload=True, verbose=False)
            data = raw_band.get_data(picks='eeg')
            n_ch = data.shape[0]
            raw_band.close()

            if n_ch == 0:
                patient_feats.extend(np.zeros(len(stats) * 10 * 2))
                continue

            feature_matrix = np.array([_compute_channel_features(data[ch, :]) for ch in range(n_ch)])

            ez_chs = [i for i in row['EZ'] if i < n_ch]
            nez_chs = [i for i in row['NEZ'] if i < n_ch]

            ez_stats = _aggregate_features(feature_matrix, ez_chs, stats)
            nez_stats = _aggregate_features(feature_matrix, nez_chs, stats)

            if ez_chs:
                band_agg_means[band_name]['EZ'] = np.mean(feature_matrix[ez_chs, :], axis=0)

            if nez_chs:
                band_agg_means[band_name]['NEZ'] = np.mean(feature_matrix[nez_chs, :], axis=0)

            patient_feats.extend(ez_stats)
            patient_feats.extend(nez_stats)

        eps = 1e-12
        for group in ['EZ', 'NEZ']:
            for band1, band2 in combinations(band_names, 2):
                e1 = band_agg_means[band1][group][9]
                e2 = band_agg_means[band2][group][9]
                patient_feats.append((e1 + eps) / (e2 + eps))

                m1 = band_agg_means[band1][group][0]
                m2 = band_agg_means[band2][group][0]
                patient_feats.append((m1 + eps) / (m2 + eps))

        row_data = [row['sample_name'], row['isCured']] + patient_feats
        all_rows.append(row_data)

    columns = ['sample_name', 'isCured'] + full_labels
    df_features = pd.DataFrame(all_rows, columns=columns)
    csv_path = output_path / "spectral_feature.csv"
    df_features.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"频谱特征已保存至: {csv_path}，共 {len(df_features)} 个样本，{len(full_labels)} 个特征。")
