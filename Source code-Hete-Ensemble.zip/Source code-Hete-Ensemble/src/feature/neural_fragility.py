"""
神经脆性核心算法模块 / Neural fragility core algorithm module.

基于线性状态转移模型 X(t+1) = A·X(t) 估计多通道信号的状态转移矩阵 A,
通过对单个通道施加微扰并观测系统响应来量化该通道的"脆性"。

Estimates the state-transition matrix A of a multi-channel signal via the linear
model X(t+1) = A·X(t), then quantifies each channel's "fragility" by perturbing
that channel and observing the system response.

依赖 / Dependencies: numpy
"""

import numpy as np

def get_window_signals(full_signal, window_size=500, repeat_rate=0.8):
    """将信号按滑动窗口切分(含重叠) / Split the signal into overlapping sliding windows."""
    window_signals = []
    n_channels, n_timepoints = full_signal.shape
    step = int(window_size * repeat_rate)
    start = 0

    while start <= n_timepoints - window_size:
        window_signals.append(full_signal[:, start:start + window_size])
        start += step

    return window_signals


def solve_state_transition_matrix(signal):
    """
    用最小二乘估计线性状态转移矩阵 A: X(t+1) = A·X(t) /
    Estimate the linear state-transition matrix A via least squares: X(t+1) = A·X(t).
    """

    n_window, n_channel = signal.shape

    X = signal[:-1, :]
    Y = signal[1:, :]

    A, _, _, _ = np.linalg.lstsq(X, Y, rcond=None)

    return A  # (n_channel, n_channel)


def get_elementary(k, n_channel):
    e = np.zeros((n_channel, 1))
    e[k] = 1
    return e


def get_B(A, k, sigma, omega):
    n_channel = A.shape[0]
    e = get_elementary(k, n_channel)
    I = np.identity(n_channel)

    A_modified = A - (sigma + omega * 1j) * I
    A_modified_inv = np.linalg.inv(A_modified)
    A_modified_inv_T = A_modified_inv.T
    B_complex = np.matmul(e.T, A_modified_inv_T)

    B = np.concatenate([B_complex.imag, B_complex.real], axis=0)
    b = np.array([0, -1]).reshape(-1, 1)
    return B, b, e

def get_perturbation(B, b, e):
    """由 B/b/e 计算对通道 k 的最优微扰矩阵 / Compute the optimal perturbation matrix for channel k."""
    B_pinv = np.linalg.pinv(B)
    temp = B @ B_pinv
    temp = temp @ b
    perturbation = temp @ e.T
    return perturbation


def get_neural_fragility(full_signal, sigma, omega, return_all=False):
    """
    计算全信号的神经脆性矩阵 / Compute the neural-fragility matrix for the full signal.

    参数 / Parameters:
        full_signal : (n_channel, n_time) 多通道信号 / Multi-channel signal.
        sigma, omega: 扰动频率参数 / Perturbation frequency parameters.
        return_all  : True 时同时返回 A 矩阵列表与滑窗脆性向量 / If True, also return A matrices & window fragility vectors.
    返回 / Returns:
        fragility_matrix (n_channel, n_windows) 以及(可选) A_matrices / window_fragility_vectors。
    """

    window_signals = get_window_signals(full_signal)
    n_channel = full_signal.shape[0]

    A_matrices = []
    window_fragility_vectors = []
    fragility_matrix_list = []

    for window_signal in window_signals:

        window_signal_T = window_signal.T

        A = solve_state_transition_matrix(window_signal_T)
        A_matrices.append(A)

        fragility_vector = []
        for k in range(n_channel):
            B, b_vec, e_vec = get_B(A, k, sigma, omega)
            perturbation = get_perturbation(B, b_vec, e_vec)

            norm = np.sqrt(np.sum(perturbation * perturbation))
            fragility_vector.append(norm)

        fragility_vector = np.array(fragility_vector)
        window_fragility_vectors.append(fragility_vector)
        fragility_matrix_list.append(fragility_vector)

    fragility_matrix = np.array(fragility_matrix_list).T  # (n_channel, n_windows)

    if return_all:
        return {
            'fragility_matrix': fragility_matrix,
            'A_matrices': A_matrices,
            'window_fragility_vectors': window_fragility_vectors
        }
    else:
        return fragility_matrix