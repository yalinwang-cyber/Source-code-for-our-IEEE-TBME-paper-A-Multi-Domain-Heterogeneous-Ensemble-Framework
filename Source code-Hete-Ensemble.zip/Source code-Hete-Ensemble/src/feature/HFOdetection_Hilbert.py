"""
HFO 检测(Hilbert 包络法)模块 / HFO detection (Hilbert envelope) module.

实现基于 Hilbert 变换包络的 Ripple 与 Fast Ripple 自动检测器。
输入多通道信号, 输出每通道事件发生率与事件属性列表。

Implements an automatic Ripple & Fast Ripple detector based on the Hilbert-transform
envelope. Takes multi-channel signals and returns per-channel event rates plus event
attribute lists.

依赖 / Dependencies: numpy, scipy
"""

import numpy as np
import warnings
from scipy import signal
from scipy.ndimage import binary_opening

def HFODetector_Hilbert(Data, SamplingRate):
    """
    [RippleRate, FastRippleRate, Ripples, FastRipples] = HFODetector_Hilbert(Data, SamplingRate)

    基于 Hilbert 变换包络的 Ripple / Fast Ripple 自动检测器 /
    Automatic ripple and fast ripple detector using Hilbert Transform Envelope.

    参数 / Parameters:
        Data          : (n_samples, n_channels) 多通道信号 / Multi-channel signal.
        SamplingRate  : 采样率(Hz) / Sampling rate in Hz.
    返回 / Returns:
        RippleRate, FastRippleRate : 每通道事件发生率 / Per-channel event rates.
        Ripples, FastRipples       : 事件属性数组 / Event attribute arrays.
    """
    # Algorithm parameters
    #WindowLength = 1 # Background moving window length [seconds]
    #Threshold = 2  # Threshold (Envelope of background times this value)
    WindowLength = 5 # Background moving window length [seconds]
    Threshold = 3  # Threshold (Envelope of background times this value)

    # Initializations
    Duration = Data.shape[0] / SamplingRate / 60
    NumberOfSamples = Data.shape[0]
    WindowLength = round(WindowLength * SamplingRate)
    if NumberOfSamples < WindowLength + 1:
        WindowLength = NumberOfSamples - 3
    MinimumSeparation = round(0.008 * SamplingRate)  # Minimum separation between events [samples]
    MinimumSeparationRipple = round(0.02 * SamplingRate)  # For ripples
    BandpassFilterOrder = 200
    NarrowbandFilterOrder = 508
    NumberOfChannels = Data.shape[1]

    # Filters (one general bandpass filter and many narrowband filters)
    nyquist = 0.5 * SamplingRate
    f_nyq = min(0.45 * SamplingRate, 500)
    f_stop = min(f_nyq + 15, 515)
    bands = np.array([0, 65, 80, f_nyq, f_stop, nyquist])
    desired = [0, 1, 0]
    weights = [10, 1, 1]
    BandpassFilter = signal.remez(BandpassFilterOrder, bands / nyquist, desired, weight=weights, fs=2)

    FrequencyBands = np.array([80, 90, 105, 120, 140, 160, 185, 215, 250, 285, 330, 380, 435, 500]) / SamplingRate
    FrequencyBands[FrequencyBands > 0.45] = np.nan
    FrequencyBands = FrequencyBands[~np.isnan(FrequencyBands)]
    NumberOfBands = len(FrequencyBands) - 1
    NarrowBandFilters = np.zeros((NumberOfBands, NarrowbandFilterOrder + 1))

    for ii in range(NumberOfBands):
        f_start = FrequencyBands[ii]
        f_end = FrequencyBands[ii + 1]
        bands_nb = np.array([0, f_start - 7 / SamplingRate, f_start + 3 / SamplingRate,
                             f_end - 3 / SamplingRate, f_end + 7 / SamplingRate, 0.5])
        desired_nb = [0, 1, 0]
        weights_nb = [10, 1, 1]
        try:
            NarrowBandFilters[ii, :] = signal.remez(NarrowbandFilterOrder, bands_nb, desired_nb,
                                                    weight=weights_nb, fs=2)
        except ValueError as e:
            warnings.warn(f"Filter design failed for band {ii}: {e}. Using approximation.")
            h_low = f_start + 3 / SamplingRate
            h_high = f_end - 3 / SamplingRate
            NarrowBandFilters[ii, :] = signal.firwin(NarrowbandFilterOrder + 1, [h_low, h_high],
                                                     pass_zero=False, fs=2)

    FrequencyBands = (FrequencyBands[:-1] + FrequencyBands[1:]) / 2 * SamplingRate  # Center freq [Hz]

    # Minimum length of the Events
    impulse_response = np.arange(-NarrowbandFilterOrder // 2, NarrowbandFilterOrder // 2 + 1)
    impulse_sq = np.tile(impulse_response ** 2, (NumberOfBands, 1))
    filters_sq = NarrowBandFilters ** 2
    group_delay = np.sqrt(np.sum(impulse_sq * filters_sq, axis=1) / np.sum(filters_sq, axis=1))
    norm_freq = FrequencyBands / SamplingRate
    MinimumLength = np.round(group_delay + 4 / norm_freq).astype(int)

    events_list = []
    Offset = (NarrowbandFilterOrder + BandpassFilterOrder) // 2

    # Bandpass filtering
    pad_len_bp = BandpassFilterOrder // 2
    Data_padded_bp = np.vstack([np.zeros((pad_len_bp, NumberOfChannels)), Data])
    BandpassSignal = signal.lfilter(BandpassFilter, [1], Data_padded_bp, axis=0)
    BandpassSignal = BandpassSignal[pad_len_bp:, :]

    # For each frequency band
    for ii in range(NumberOfBands):
        # Narrow band signal
        pad_len_nb = NarrowbandFilterOrder // 2
        Bandpass_padded = np.vstack([np.zeros((pad_len_nb, NumberOfChannels)), BandpassSignal])
        NarrowbandSignal = signal.lfilter(NarrowBandFilters[ii, :], [1], Bandpass_padded, axis=0)
        NarrowbandSignal = NarrowbandSignal[pad_len_nb:, :]

        # ----------------------------------------------------
        # CHANGED: Compute Envelope using Hilbert Transform
        # ----------------------------------------------------
        analytic_signal = signal.hilbert(NarrowbandSignal, axis=0)
        EnvelopeSignal = np.abs(analytic_signal)

        # ----------------------------------------------------
        # Using Envelope mapped Iterative Background Estimator
        # ----------------------------------------------------
        MovingBackground = EnvelopeSignal.copy()
        init_mean = np.mean(EnvelopeSignal[:WindowLength, :], axis=0)
        MovingBackground[:WindowLength, :] = np.tile(init_mean, (WindowLength, 1))
        IterativeBackgroundEstimator = EnvelopeSignal.copy()

        # Keep equivalent shift logic for background stabilization comparable to RMS delay
        shift = int(np.floor(2 / norm_freq[ii]))

        for jj in range(WindowLength, NumberOfSamples):
            if jj - shift < 0:
                continue
            idx = jj - shift
            IterativeBackgroundEstimator[jj, :] = np.minimum(EnvelopeSignal[idx, :],
                                                             Threshold * MovingBackground[idx, :])
            MovingBackground[jj, :] = MovingBackground[jj - 1, :] + \
                                      (IterativeBackgroundEstimator[jj, :] - IterativeBackgroundEstimator[
                                          jj - WindowLength, :]) / WindowLength

        # First detections using Envelope instead of RMS
        CandidateDetections = EnvelopeSignal > Threshold * MovingBackground

        # Ignore edges
        CandidateDetections[:Offset, :] = False
        CandidateDetections[-Offset:, :] = False

        # Keep only detections of enough length
        struct = np.ones((MinimumLength[ii], 1))
        CandidateDetections = binary_opening(CandidateDetections, structure=struct).astype(bool)

        # Get event characteristics
        diff_cand = np.diff(CandidateDetections.astype(float), axis=0)
        starts_idx, starts_ch = np.where(diff_cand == 1)
        ends_idx, ends_ch = np.where(diff_cand == -1)
        EventStart = starts_idx + 1
        EventEnd = ends_idx + 1
        if len(EventStart) != len(EventEnd):
            min_len = min(len(EventStart), len(EventEnd))
            EventStart = EventStart[:min_len]
            EventEnd = EventEnd[:min_len]
            starts_ch = starts_ch[:min_len]
            ends_ch = ends_ch[:min_len]
        EventLength = EventEnd - EventStart + 1
        DetectionChannel = starts_ch
        NumberOfEvents = len(EventStart)

        Values = np.ones((NumberOfEvents, 7))
        for jj in range(NumberOfEvents):
            ch = DetectionChannel[jj]
            start_idx = EventStart[jj]
            end_idx = EventEnd[jj]
            # Characteristics calculation adjusted for Envelope
            seg_env_ratio = EnvelopeSignal[start_idx:end_idx + 1, ch] / MovingBackground[start_idx:end_idx + 1, ch]
            seg_env = EnvelopeSignal[start_idx:end_idx + 1, ch]
            seg_nb = NarrowbandSignal[start_idx:end_idx + 1, ch]
            seg_bp = BandpassSignal[start_idx:end_idx + 1, ch]
            seg_raw = Data[start_idx:end_idx + 1, ch]
            Values[jj, 0] = np.max(seg_env_ratio)  # Replaced MaxRMS Ratio with Envelope Ratio
            Values[jj, 1] = np.max(seg_env)  # Replaced MaxRMS with Max Envelope
            Values[jj, 2] = np.max(np.abs(seg_nb))
            Values[jj, 3] = np.max(np.abs(seg_bp))
            Values[jj, 4] = np.max(seg_nb)
            Values[jj, 5] = np.min(seg_nb)
            Values[jj, 6] = np.max(np.abs(np.diff(seg_raw)))

        freq_col = np.full(NumberOfEvents, FrequencyBands[ii])
        DetectedEvents = np.column_stack([DetectionChannel, freq_col, EventStart, EventLength, Values])
        events_list.append(DetectedEvents)

    if events_list:
        Event = np.vstack(events_list)
    else:
        Event = np.empty((0, 11))

    event = Event.copy()

    if Event.shape[0] > 0:
        event = np.column_stack([Event[:, [0, 1, 2, 3, 4, 8, 9, 10]], np.ones(Event.shape[0])])
    Ripples = np.zeros((Event.shape[0], 9))
    FastRipples = np.zeros((Event.shape[0], 9))
    RippleCounter = 0
    FastRippleCounter = 0

    # Helper function for merging
    def merge_events(EventsInChannel, min_sep):
        if EventsInChannel.shape[0] == 0:
            return np.empty((0, 9))
        sort_idx = np.argsort(EventsInChannel[:, 2])
        EventsInChannel = EventsInChannel[sort_idx]
        merged = []
        i = 0
        while i < EventsInChannel.shape[0]:
            current = EventsInChannel[i].copy()
            j = i + 1
            while j < EventsInChannel.shape[0]:
                if EventsInChannel[j, 2] < current[2] + current[3] + min_sep:
                    current[1] = np.mean([current[1], EventsInChannel[j, 1]])  # freq mean
                    current[3] = np.max(
                        [current[3], EventsInChannel[j, 3] + EventsInChannel[j, 2] - current[2]])  # extend dur
                    current[4] = np.max([current[4], EventsInChannel[j, 4]])  # max ratio
                    current[5] = np.max([current[5], EventsInChannel[j, 5]])  # max maxnb
                    current[6] = np.min([current[6], EventsInChannel[j, 6]])  # min minnb
                    current[7] = np.max([current[7], EventsInChannel[j, 7]])  # max absdiff
                    current[8] = current[8] + EventsInChannel[j, 8]  # sum count
                    j += 1
                else:
                    break
            merged.append(current)
            i = j
        return np.array(merged)

    # Ripples
    for ChannelNumber in range(NumberOfChannels):
        EventsInChannel = event[(event[:, 0] == ChannelNumber) & (event[:, 1] < 250), :]
        ChannelEvent = merge_events(EventsInChannel, MinimumSeparationRipple)
        num_ch = ChannelEvent.shape[0]
        if num_ch > 0:
            Ripples[RippleCounter:RippleCounter + num_ch, :] = ChannelEvent
            RippleCounter += num_ch

    # Fast ripples
    for ChannelNumber in range(NumberOfChannels):
        EventsInChannel = event[(event[:, 0] == ChannelNumber) & (event[:, 1] > 250), :]
        ChannelEvent = merge_events(EventsInChannel, MinimumSeparation)
        num_ch = ChannelEvent.shape[0]
        if num_ch > 0:
            FastRipples[FastRippleCounter:FastRippleCounter + num_ch, :] = ChannelEvent
            FastRippleCounter += num_ch

    Ripples = Ripples[:RippleCounter, :]
    FastRipples = FastRipples[:FastRippleCounter, :]

    # Compute rates
    RippleRate = np.zeros(NumberOfChannels)
    FastRippleRate = np.zeros(NumberOfChannels)
    for ChannelNumber in range(NumberOfChannels):
        RippleRate[ChannelNumber] = np.sum(Ripples[:, 0] == ChannelNumber)
        FastRippleRate[ChannelNumber] = np.sum(FastRipples[:, 0] == ChannelNumber)
    if Duration > 0:
        RippleRate /= Duration
        FastRippleRate /= Duration

    return RippleRate, FastRippleRate, Ripples, FastRipples
