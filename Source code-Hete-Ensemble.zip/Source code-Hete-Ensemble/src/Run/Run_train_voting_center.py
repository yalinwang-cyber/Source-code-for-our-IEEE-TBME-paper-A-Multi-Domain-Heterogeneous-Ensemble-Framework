"""
异质集成训练与评估主入口脚本 / Heterogeneous ensemble training & evaluation entry script.

本脚本完成整个异质集成的训练与评估流程:
  1) 定义 15 个专家(四元组: 时间窗, 特征域, 选择器, 分类器)
  2) 按 LOCO(Leave-One-Center-Out)训练各专家并保存预测概率
  3) 集成评估(soft voting + 全局阈值 tau=0.56)
  4) 单专家评估
  5) 留一专家消融实验
  6) 阈值扫描

This script runs the full heterogeneous-ensemble training & evaluation:
  1) Define 15 experts (tuple: time window, feature domain, selector, classifier)
  2) Train each expert under LOCO and cache predicted probabilities
  3) Ensemble evaluation (soft voting + global threshold tau=0.56)
  4) Per-expert evaluation
  5) Leave-one-expert-out ablation
  6) Threshold sweep

被调用的主要函数 / Key functions called:
  - src.train.expert_probs.train_center_voting  : LOCO 训练并保存专家概率 / LOCO train & save expert probs
  - src.train.eval_utils.generate_expert_names  : 生成专家命名 / Generate expert names
  - src.train.ensemble_eval.evaluate_ensemble   : 集成评估 / Ensemble evaluation
  - src.train.expert_eval.evaluate_experts      : 单专家评估 / Per-expert evaluation
  - src.train.ablation_eval.evaluate_ablation   : 留一专家消融 / Leave-one-expert-out ablation
  - src.train.threshold_scan.scan_thresholds    : 阈值扫描 / Threshold sweep
"""

from src.preprocess.utils import load_data
from src.train.expert_probs   import train_center_voting
from src.train.ensemble_eval  import evaluate_ensemble
from src.train.expert_eval    import evaluate_experts
from src.train.ablation_eval  import evaluate_ablation
from src.train.eval_utils     import generate_expert_names
from src.train.threshold_scan   import scan_thresholds
import numpy as np

import warnings
warnings.filterwarnings('ignore')

# 15 个专家配置(按覆盖规则人工固定)
#   - 七域至少各一
#   - 五种选择器与六种分类器全覆盖
#   - 六种时间窗全覆盖
#   - 任意两专家至少一维不同
# 15-expert config (manually fixed by coverage rule):
#   - all 7 domains covered
#   - all 5 selectors & 6 classifiers covered
#   - all 6 time windows covered
#   - any two experts differ in at least one dimension
experts_config = [
    {'feature_path': 'data/10start/feature', 'domains': ['spectral'],
     'model': 'LR2',  'selector': 'boruta',   'k': 40},
    {'feature_path': 'data/20start/feature', 'domains': ['spectral'],
     'model': 'LDA',  'selector': 'boruta',   'k': 40},
    {'feature_path': 'data/10start/feature', 'domains': ['dwt'],
     'model': 'LR2',  'selector': 'fClassif', 'k': 40},
    {'feature_path': 'data/10start/feature', 'domains': ['dwt'],
     'model': 'LR1',  'selector': 'l1',       'k': 40},
    {'feature_path': 'data/30start/feature', 'domains': ['dwt'],
     'model': 'XGB',  'selector': 'mrmr',     'k': 40},
    {'feature_path': 'data/30mid/feature',   'domains': ['cwt'],
     'model': 'XGB',  'selector': 'mi',       'k': 40},
    {'feature_path': 'data/10start/feature', 'domains': ['cwt'],
     'model': 'MLP',  'selector': 'boruta',   'k': 40},
    {'feature_path': 'data/20start/feature', 'domains': ['connectivity'],
     'model': 'MLP',  'selector': 'mrmr',     'k': 40},
    {'feature_path': 'data/10start/feature', 'domains': ['connectivity'],
     'model': 'MLP',  'selector': 'l1',       'k': 40},
    {'feature_path': 'data/20mid/feature',   'domains': ['graph'],
     'model': 'MLP',  'selector': 'fClassif', 'k': 40},
    {'feature_path': 'data/20start/feature', 'domains': ['hfo'],
     'model': 'LR2',  'selector': 'l1',       'k': 40},
    {'feature_path': 'data/10start/feature', 'domains': ['hfo'],
     'model': 'LR2',  'selector': 'fClassif', 'k': 40},
    {'feature_path': 'data/30start/feature', 'domains': ['fragility'],
     'model': 'LDA',  'selector': 'boruta',   'k': 40},
    {'feature_path': 'data/10start/feature', 'domains': ['fragility'],
     'model': 'XGB',  'selector': 'l1',       'k': 40},
    {'feature_path': 'data/10mid/feature',   'domains': ['fragility'],
     'model': 'KNN',  'selector': 'mi',       'k': 40},
]

# 基础随机种子 / Base random seed
base_seed  = 42
# 全局 soft voting 阈值 / Global soft-voting threshold
threshold  = 0.56
# 实验名 / Experiment name
exp_name   = f'Final_Config'
# 专家概率缓存目录 / Directory for cached expert probabilities
results_dir = f'results/Expert_prob'

config = {
    'experts_config': experts_config,
    'base_seed':      base_seed,
    'exp_name':       exp_name,
    'results_dir':    results_dir,
    'threshold':      threshold,
}

# 读取患者元数据
# Load patient metadata
patient_data = load_data()

# Step 1: LOCO 训练并保存各专家预测概率
# Step 1: LOCO train & save each expert's predicted probabilities
train_center_voting(patient_data, config)

# 生成专家命名(用于匹配缓存目录)
# Generate expert names (used to locate cached folders)
expert_names = generate_expert_names(experts_config)

# Step 2: 集成整体评估(soft voting)
# Step 2: Overall ensemble evaluation (soft voting)
evaluate_ensemble(results_dir, expert_names, base_seed, threshold)

# Step 3: 单专家评估
# Step 3: Per-expert evaluation
evaluate_experts(results_dir, expert_names, base_seed, threshold)

# Step 4: 留一专家消融
# Step 4: Leave-one-expert-out ablation
evaluate_ablation(results_dir, expert_names, base_seed, threshold)

# Step 5: 阈值扫描(0.30–0.80, 步长 0.05)
# Step 5: Threshold sweep (0.30–0.80, step 0.05)
scan_thresholds(results_dir, expert_names, base_seed,
                thresholds=np.round(np.arange(0.30, 0.805, 0.05), 2),
                target_threshold=0.56)
