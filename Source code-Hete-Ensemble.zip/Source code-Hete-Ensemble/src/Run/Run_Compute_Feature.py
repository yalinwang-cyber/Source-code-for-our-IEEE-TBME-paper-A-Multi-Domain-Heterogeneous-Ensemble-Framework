"""
七域特征计算主入口脚本 / 7-domain feature extraction entry script.

本脚本对 6 种时间窗分别计算 7 个特征域的特征, 并输出 CSV:
  - Spectral      : 频谱特征(7 频带统计量 + 频带比值)
  - DWT           : 离散小波变换(Daubechies-4, 6 层)
  - CWT           : 连续小波变换(Morlet, 8 尺度)
  - Connectivity  : 功能连接(Coherence / PLV / wPLI)
  - Graph         : 图论特征(强度/介数/聚类系数)
  - HFO           : 高频振荡(Hilbert 包络检测 Ripple/Fast Ripple)
  - Neural Fragility : 神经脆性(线性状态转移模型)

This script extracts 7 feature domains for each of the 6 time windows and
writes them to CSV:
  - Spectral, DWT, CWT, Connectivity, Graph, HFO, Neural Fragility

被调用的主要函数 / Key functions called:
  - src.feature.spectral_feature.compute_all_spectral_features
  - src.feature.dwt_feature.compute_all_dwt_features
  - src.feature.cwt_feature.compute_all_cwt_features
  - src.feature.connectivity_feature.compute_all_connectivity_features
  - src.feature.graph_feature.compute_all_graph_features
  - src.feature.hfo_feature.compute_all_hfo_features
  - src.feature.fragility_feature.compute_all_fragility_features
"""

from src.feature.connectivity_feature import compute_all_connectivity_features
from src.feature.cwt_feature import compute_all_cwt_features
from src.feature.dwt_feature import compute_all_dwt_features
from src.feature.fragility_feature import compute_all_fragility_features
from src.feature.graph_feature import compute_all_graph_features
from src.feature.hfo_feature import compute_all_hfo_features
from src.feature.spectral_feature import compute_all_spectral_features
from src.preprocess.utils import load_data

# 读取患者元数据
# Load patient metadata
patient_data = load_data()

# 选取 Example 数据集用于演示
# Select the Example dataset for demonstration
example_data = patient_data[patient_data['Dataset'] == 'Example'].reset_index(drop=True)

# 六种时间窗 / Six time windows
windows = ['10start', '10mid', '20start', '20mid', '30start', '30mid']

# 7 个频带定义 / 7 frequency-band definitions
bands = {
    'delta':  (0.5, 4),
    'theta':  (4, 8),
    'alpha':  (8, 13),
    'beta':   (13, 30),
    'gamma1': (30, 45),
    'gamma2': (45, 80),
    'gamma3': (80, 125)
}

# 逐个时间窗计算七域特征 / Compute 7 domains per time window
for win in windows:
    base = f"data/Example/{win}"
    filter_01_path = f"{base}/filter_01"   # 0.5–125 Hz 带通
    filter_02_path = f"{base}/filter_02"   # 80–500 Hz 带通(HFO)
    filter_03_path = f"{base}/filter_03"   # 7 频带分割
    feature_path = f"{base}/feature"

    # 频谱特征(基于 7 频带分割数据)
    # Spectral features (based on 7-band split data)
    print(">> 计算频谱特征...")
    compute_all_spectral_features(
        patient_data=example_data,
        base_path=filter_03_path,
        output_path=feature_path,
        band_names=list(bands.keys())
    )

    # DWT 特征(基于 0.5–125 Hz 带通数据, db4 小波, 6 层分解)
    # DWT features (0.5–125 Hz bandpass, db4 wavelet, 6 levels)
    print(">> 计算 DWT 特征...")
    compute_all_dwt_features(
        patient_data=example_data,
        base_path=filter_01_path,
        output_path=feature_path,
        wavelet='db4'
    )

    # CWT 特征(基于 0.5–125 Hz 带通数据, Morlet 小波, 8 尺度)
    # CWT features (0.5–125 Hz bandpass, Morlet wavelet, 8 scales)
    print(">> 计算 CWT 特征...")
    compute_all_cwt_features(
        patient_data=example_data,
        base_path=filter_01_path,
        output_path=feature_path,
        f_min=0.5,
        f_max=125.0,
        wavelet='morl',
        num_scales=8
    )

    # 功能连接特征(基于 7 频带, Coh/PLV/wPLI)
    # Functional connectivity (7 bands, Coh/PLV/wPLI)
    print(">> 计算连接特征...")
    compute_all_connectivity_features(
        patient_data=example_data,
        base_path=filter_03_path,
        output_path=feature_path,
        bands=bands,
        duration=2
    )

    # 图论特征(基于功能连接矩阵)
    # Graph-theory features (based on connectivity matrices)
    print(">> 计算图论特征...")
    compute_all_graph_features(
        patient_data=example_data,
        base_path=filter_03_path,
        output_path=feature_path,
        bands=bands,
        duration=2,
        n_jobs=-1,
        methods=['coh', 'plv', 'wpli'],
    )

    # HFO 特征(基于 80–500 Hz 带通数据)
    # HFO features (80–500 Hz bandpass)
    print(">> 计算HFO特征...")
    compute_all_hfo_features(
        patient_data=example_data,
        base_path=filter_02_path,
        output_path=feature_path,
        n_jobs=-1
    )

    # 神经脆性特征(基于 0.5–125 Hz 带通数据)
    # Neural fragility features (0.5–125 Hz bandpass)
    print(">> 计算神经脆性特征...")
    compute_all_fragility_features(
        patient_data=example_data,
        base_path=filter_01_path,
        output_path=feature_path,
        n_jobs=-1
    )
