"""
数据预处理主入口脚本 / Data preprocessing entry script.

本脚本完成颅内脑电(iEEG)的统一预处理流水线：
  1) 按 6 种时间窗配置截取发作片段
  2) 陷波滤波(去除 50/60 Hz 工频干扰及其谐波)
  3) 三条并行滤波流：
       - filter_01: 0.5–125 Hz 带通(供 DWT/CWT/神经脆性使用)
       - filter_02: 80–500 Hz 带通(供 HFO 检测使用)
       - filter_03: 7 频带分割(供 Spectral/Connectivity/Graph 使用)

This script runs the unified iEEG preprocessing pipeline:
  1) Crop seizure segments under 6 time-window configurations
  2) Notch filtering (remove 50/60 Hz line noise and harmonics)
  3) Three parallel filter streams:
       - filter_01: 0.5–125 Hz bandpass (for DWT/CWT/Neural Fragility)
       - filter_02: 80–500 Hz bandpass (for HFO detection)
       - filter_03: 7-band split (for Spectral/Connectivity/Graph)

被调用的主要函数 / Key functions called:
  - src.preprocess.utils.load_data                 : 读取患者元数据 / Load patient metadata
  - src.preprocess.crop.crop_start / crop_mid      : 时间窗截取 / Time-window cropping
  - src.preprocess.filter.notch_filter             : 陷波滤波 / Notch filtering
  - src.preprocess.filter.bandpass_filter          : 带通滤波 / Bandpass filtering
  - src.preprocess.filter.bandsplit_filter         : 分频带滤波 / Band-split filtering
"""

from src.preprocess.filter import notch_filter, bandpass_filter, bandsplit_filter
from src.preprocess.crop import crop_start, crop_mid
from src.preprocess.utils import load_data

# 读取患者元数据(data.csv)
# Load patient metadata from data.csv
patient_data = load_data()

# 选取 Example 数据集用于演示(实际全量数据处理时替换为对应中心即可)
# Select the Example dataset for demonstration
# (replace with the target center when processing the full dataset)
example_data = patient_data[patient_data['Dataset'] == 'Example'].reset_index(drop=True)

# 原始 iEEG 所在目录
# Directory holding the raw iEEG (.fif) files
iEEG_path = "data/iEEG"

# ---------- 1. 六种时间窗截取 / Six time-window cropping ----------
# start: 自发作起始向前截取 time 秒 / Crop `time` seconds forward from onset
# mid  : 以发作中点为中心向两侧截取 time 秒 / Crop `time` seconds centered at midpoint
crop_start(example_data, iEEG_path, "data/Example/10start/crop", 10)
crop_mid(example_data, iEEG_path, "data/Example/10mid/crop", 10)
crop_start(example_data, iEEG_path, "data/Example/20start/crop", 20)
crop_mid(example_data, iEEG_path, "data/Example/20mid/crop", 20)
crop_start(example_data, iEEG_path, "data/Example/30start/crop", 30)
crop_mid(example_data, iEEG_path, "data/Example/30mid/crop", 30)

# ---------- 2. 陷波滤波 / Notch filtering ----------
# 按中心选择 50 Hz 或 60 Hz, 并去除其谐波
# Choose 50 Hz or 60 Hz according to the center, remove its harmonics
notch_filter(example_data, "data/Example/10start/crop", "data/Example/10start/notch")
notch_filter(example_data, "data/Example/20start/crop", "data/Example/20start/notch")
notch_filter(example_data, "data/Example/30start/crop", "data/Example/30start/notch")
notch_filter(example_data, "data/Example/10mid/crop", "data/Example/10mid/notch")
notch_filter(example_data, "data/Example/20mid/crop", "data/Example/20mid/notch")
notch_filter(example_data, "data/Example/30mid/crop", "data/Example/30mid/notch")

# ---------- 3. 三条滤波流 / Three filter streams ----------

# a) 带通滤波 0.5 Hz - 125 Hz (供 DWT / CWT / 神经脆性使用)
# a) Bandpass 0.5–125 Hz (used by DWT / CWT / Neural Fragility)
bandpass_filter(example_data, "data/Example/10start/notch", "data/Example/10start/filter_01", 0.5, 125)
bandpass_filter(example_data, "data/Example/10mid/notch", "data/Example/10mid/filter_01", 0.5, 125)
bandpass_filter(example_data, "data/Example/20start/notch", "data/Example/20start/filter_01", 0.5, 125)
bandpass_filter(example_data, "data/Example/20mid/notch", "data/Example/20mid/filter_01", 0.5, 125)
bandpass_filter(example_data, "data/Example/30start/notch", "data/Example/30start/filter_01", 0.5, 125)
bandpass_filter(example_data, "data/Example/30mid/notch", "data/Example/30mid/filter_01", 0.5, 125)

# b) 带通滤波 80 Hz - 500 Hz (供 HFO 检测使用)
# b) Bandpass 80–500 Hz (used by HFO detection)
bandpass_filter(example_data, "data/Example/10start/notch", "data/Example/10start/filter_02", 80, 500)
bandpass_filter(example_data, "data/Example/10mid/notch", "data/Example/10mid/filter_02", 80, 500)
bandpass_filter(example_data, "data/Example/20start/notch", "data/Example/20start/filter_02", 80, 500)
bandpass_filter(example_data, "data/Example/20mid/notch", "data/Example/20mid/filter_02", 80, 500)
bandpass_filter(example_data, "data/Example/30start/notch", "data/Example/30start/filter_02", 80, 500)
bandpass_filter(example_data, "data/Example/30mid/notch", "data/Example/30mid/filter_02", 80, 500)

# c) 频段分割 0.5 Hz - 125 Hz (供 Spectral / Connectivity / Graph 使用)
# c) Band split 0.5–125 Hz (used by Spectral / Connectivity / Graph)
bands = {
    'delta':  (0.5, 4),
    'theta':  (4, 8),
    'alpha':  (8, 13),
    'beta':   (13, 30),
    'gamma1': (30, 45),
    'gamma2': (45, 80),
    'gamma3': (80, 125)
}
bandsplit_filter(example_data, "data/Example/10start/notch", "data/Example/10start/filter_03", bands)
bandsplit_filter(example_data, "data/Example/10mid/notch", "data/Example/10mid/filter_03", bands)
bandsplit_filter(example_data, "data/Example/20start/notch", "data/Example/20start/filter_03", bands)
bandsplit_filter(example_data, "data/Example/20mid/notch", "data/Example/20mid/filter_03", bands)
bandsplit_filter(example_data, "data/Example/30start/notch", "data/Example/30start/filter_03", bands)
bandsplit_filter(example_data, "data/Example/30mid/notch", "data/Example/30mid/filter_03", bands)
