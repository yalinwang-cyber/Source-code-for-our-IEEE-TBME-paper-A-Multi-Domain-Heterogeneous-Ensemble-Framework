"""
L2 正则化逻辑回归分类器 / L2-regularized logistic regression classifier.

依赖 / Dependencies: scikit-learn
"""

from sklearn.linear_model import LogisticRegression

def build_lr_l2(random_seed=42, fold_idx=0):
    """返回未训练的 L2 正则化逻辑回归模型 / Return an untrained L2 logistic-regression model."""
    return LogisticRegression(
        penalty='l2',
        C=1.0,
        solver='liblinear',
        random_state=random_seed,
        max_iter=1000
    )
