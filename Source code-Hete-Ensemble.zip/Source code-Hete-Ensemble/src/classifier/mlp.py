"""
MLP(多层感知机)分类器 / Multi-Layer Perceptron classifier.

依赖 / Dependencies: scikit-learn
"""

from sklearn.neural_network import MLPClassifier

def build_mlp(random_seed=42, fold_idx=0):
    """返回未训练的 MLP 模型 / Return an untrained MLP model."""
    return MLPClassifier(
        hidden_layer_sizes=(100, 50),
        activation='relu',
        solver='adam',
        alpha=0.0001,
        batch_size='auto',
        learning_rate='adaptive',
        learning_rate_init=0.001,
        max_iter=500,
        early_stopping=True,
        validation_fraction=0.1,
        n_iter_no_change=10,
        random_state=random_seed
    )
