"""
KNN 分类器 / K-Nearest Neighbors classifier.

依赖 / Dependencies: scikit-learn
"""

from sklearn.neighbors import KNeighborsClassifier

def build_knn(random_seed=42, fold_idx=0, n_neighbors=5):
    """返回未训练的 KNN 模型 / Return an untrained KNN model."""
    return KNeighborsClassifier(n_neighbors=n_neighbors, weights='distance', n_jobs=-1)
