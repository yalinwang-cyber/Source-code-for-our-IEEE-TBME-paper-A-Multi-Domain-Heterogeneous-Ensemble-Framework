"""
LDA 分类器 / Linear Discriminant Analysis classifier.

依赖 / Dependencies: scikit-learn
"""

from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

def build_lda(random_seed=42, fold_idx=0):
    """返回未训练的 LDA 模型 / Return an untrained LDA model."""
    return LinearDiscriminantAnalysis(
        solver='svd',
        shrinkage=None,
        priors=None,
        store_covariance=False
    )
