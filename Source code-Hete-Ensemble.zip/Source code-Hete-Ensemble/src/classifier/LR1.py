"""
L1 正则化逻辑回归分类器 / L1-regularized logistic regression classifier.

依赖 / Dependencies: scikit-learn
"""

from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
import warnings
warnings.filterwarnings('ignore', category=FutureWarning, module='sklearn.linear_model')
warnings.filterwarnings('ignore', category=UserWarning, module='sklearn.linear_model')
warnings.filterwarnings('ignore', category=ConvergenceWarning, module='sklearn.linear_model')

def build_lr_l1(random_seed=42, fold_idx=0):
    """返回未训练的 L1 正则化逻辑回归模型 / Return an untrained L1 logistic-regression model."""
    return LogisticRegression(
        penalty='l1',
        C=1.0,
        solver='saga',
        random_state=random_seed,
        max_iter=1000,
        class_weight='balanced'
    )
