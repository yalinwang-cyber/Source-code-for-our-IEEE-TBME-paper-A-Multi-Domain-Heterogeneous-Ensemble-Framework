"""
XGBoost 分类器 / XGBoost classifier.

依赖 / Dependencies: xgboost
"""

from xgboost import XGBClassifier

def build_xgb(random_seed=42, fold_idx=0):
    """返回未训练的 XGBoost 模型 / Return an untrained XGBoost model."""
    return XGBClassifier(
        n_estimators=100,
        max_depth=6,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        reg_alpha=0.1,
        reg_lambda=1.0,
        eval_metric='logloss',
        random_state=random_seed,
        verbosity=0
    )
