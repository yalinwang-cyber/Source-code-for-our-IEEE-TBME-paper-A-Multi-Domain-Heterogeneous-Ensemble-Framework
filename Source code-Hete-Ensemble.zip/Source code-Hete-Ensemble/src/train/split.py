"""
数据划分模块 / Data splitting module.

实现 Leave-One-Center-Out (LOCO): 按临床中心划分训练/测试集。
Implements Leave-One-Center-Out (LOCO): split train/test by clinical center.

依赖 / Dependencies: numpy
"""

import numpy as np

def splitByCenter(center_labels):
    """
    LOCO 划分: 逐个中心作为测试集, 其余作为训练集 /
    LOCO split: hold out one center as test, the rest as train.

    参数 / Parameters:
        center_labels : 每个样本的中心标签 / Per-sample center labels.
    生成 / Yields:
        train_idx, test_idx, fold_idx, center_name
    """
    unique_centers = np.unique(center_labels)
    for fold_idx, center in enumerate(unique_centers, 1):
        test_mask = center_labels == center
        train_idx = np.where(~test_mask)[0]
        test_idx = np.where(test_mask)[0]
        yield train_idx, test_idx, fold_idx, str(center)
