"""
留一专家消融评估模块 / Leave-one-expert-out ablation module.

每次移除一个专家后重新做 soft voting, 评估集成性能变化, 输出 leave_one_expert_out.csv。
Removes one expert at a time and re-runs soft voting to measure the ensemble
performance change; outputs leave_one_expert_out.csv.

依赖 / Dependencies: pandas, scikit-learn
"""

import pandas as pd

from src.train.eval_utils import (METRIC_COLS, evaluate, list_seeds, list_centers,
                        ensemble_probs, summary_by_center_seed)


def _run(results_dir, seeds, centers, experts, threshold):
    """对给定专家子集做 soft voting 并汇总指标 / Soft-vote over a given expert subset and summarize metrics."""
    per_seed_center = {}
    for seed in seeds:
        for center in centers:
            y_true, prob = ensemble_probs(results_dir, seed, experts, center)
            y_pred = (prob >= threshold).astype(int)
            per_seed_center[(seed, center)] = evaluate(y_true, y_pred, prob)
    return summary_by_center_seed(per_seed_center)


def evaluate_ablation(results_dir, expert_names, threshold):
    """
    留一专家消融实验并输出 leave_one_expert_out.csv /
    Leave-one-expert-out ablation; output leave_one_expert_out.csv.
    """
    seeds = list_seeds(results_dir)
    centers = list_centers(results_dir, expert_names[0])

    records = []

    summary = _run(results_dir, seeds, centers, expert_names, threshold)
    row = {'leave_out_expert': 'None (full ensemble)'}
    row.update({m: f"{summary.loc[m, 'mean']:.4f} ± {summary.loc[m, 'std']:.4f}"
                for m in METRIC_COLS})
    records.append(row)
    print("baseline done")

    for leave_out in expert_names:
        keep = [e for e in expert_names if e != leave_out]
        summary = _run(results_dir, seeds, centers, keep, threshold)
        row = {'leave_out_expert': leave_out}
        row.update({m: f"{summary.loc[m, 'mean']:.4f} ± {summary.loc[m, 'std']:.4f}"
                    for m in METRIC_COLS})
        records.append(row)
        print(f"done: {leave_out}")

    out = pd.DataFrame(records)
    out.to_csv('leave_one_expert_out.csv', index=False, encoding='utf-8-sig')

    def _mean(s):
        return float(str(s).split('±')[0].strip())

    base_aucpr  = _mean(out.iloc[0]['AUC_PR'])
    base_rocauc = _mean(out.iloc[0]['ROC_AUC'])
    delta = pd.DataFrame([{
        'Removed expert': r['leave_out_expert'],
        'ΔAUC-PR':  round(_mean(r['AUC_PR'])  - base_aucpr,  4),
        'ΔROC-AUC': round(_mean(r['ROC_AUC']) - base_rocauc, 4),
    } for _, r in out.iloc[1:].iterrows()])
    delta.to_csv('ablation_delta.csv', index=False, encoding='utf-8-sig')

    print("\n[ablation] 完整结果:")
    print(out[['leave_out_expert', 'ROC_AUC', 'AUC_PR',
               'Balanced_Accuracy']].to_string(index=False))
    print("\n[ablation] Δ 对照:")
    print(delta.to_string(index=False))