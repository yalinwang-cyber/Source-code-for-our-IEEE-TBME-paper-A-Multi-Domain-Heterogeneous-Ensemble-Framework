"""
特征数据加载模块 / Feature data loading module.

从指定特征目录按域加载 CSV 特征, 并与 patient_data 对齐, 返回 X / y / groups / 样本名 / 特征名。
Loads per-domain CSV features from a feature directory, aligns them with patient_data,
and returns X / y / groups / sample_names / feature_names.

依赖 / Dependencies: numpy, pandas
"""

from pathlib import Path
import numpy as np
import pandas as pd

def load_domain_features(patient_data, feature_path, domains=None):
    """
    按域加载特征并与 patient_data 对齐 / Load features by domain and align with patient_data.

    参数 / Parameters:
        patient_data : DataFrame, 含 sample_name / isCured / patient_name 列。
        feature_path : 特征目录, 内含各域 CSV / Feature dir with per-domain CSVs.
        domains      : 要加载的域列表, 默认全部 / Domains to load (default: all).
    返回 / Returns:
        X_all, y_all, groups, sample_names, all_feature_names
    """
    patient_data = patient_data.copy()
    patient_data['sample_name'] = patient_data['sample_name'].astype(str).str.strip()

    if domains is None:
        domains = ['spectral', 'dwt', 'cwt', 'connectivity', 'graph', 'hfo']

    all_domains = {
        'spectral': 'spectral_feature.csv',
        'dwt': 'dwt_feature.csv',
        'cwt': 'cwt_feature.csv',
        'connectivity': 'connectivity_feature.csv',
        'graph': 'graph_feature.csv',
        'hfo': 'hfo_feature.csv',
        'fragility': 'fragility_feature.csv',
    }

    feature_path = Path(feature_path)
    all_parts = []
    all_feature_names = []

    if 'sample_name' not in patient_data.columns:
        raise ValueError("patient_data 必须包含 sample_name 列")

    required_samples = set(patient_data['sample_name'])
    if not required_samples:
        raise ValueError("patient_data 中没有样本")

    for domain in domains:
        if domain not in all_domains:
            continue
        csv_path = feature_path / all_domains[domain]
        if not csv_path.exists():
            print(f"  警告: 特征文件不存在 {csv_path}，跳过 {domain}")
            continue
        df = pd.read_csv(csv_path)
        df['sample_name'] = df['sample_name'].astype(str).str.strip()
        if 'sample_name' not in df.columns:
            raise ValueError(f"{csv_path} 缺少 sample_name 列")
        df = df.set_index('sample_name')

        available = required_samples.intersection(df.index)
        if len(available) == 0:
            print(f"  警告: {domain} 特征文件中没有匹配的样本，跳过")
            continue
        df = df.loc[list(available)]

        feat_cols = [c for c in df.columns if c not in ('isCured',)]
        all_parts.append(df[feat_cols])
        all_feature_names.extend(feat_cols)

    if not all_parts:
        raise ValueError("没有加载到任何特征！")

    X_df = pd.concat(all_parts, axis=1)

    X_df = X_df.reindex(patient_data['sample_name'])
    X_df = X_df.replace([np.inf, -np.inf], np.nan)
    X_df = X_df.fillna(0)
    X_df = X_df.clip(lower=-1e15, upper=1e15)

    X_all = X_df.values

    patient_data_aligned = patient_data.set_index('sample_name').loc[X_df.index]
    y_all = patient_data_aligned['isCured'].astype(int).values
    groups = patient_data_aligned['patient_name'].values
    sample_names = patient_data_aligned.index.values

    print(f"  加载特征: {X_all.shape[1]} 维, {X_all.shape[0]} 样本")


    return X_all, y_all, groups, sample_names, all_feature_names