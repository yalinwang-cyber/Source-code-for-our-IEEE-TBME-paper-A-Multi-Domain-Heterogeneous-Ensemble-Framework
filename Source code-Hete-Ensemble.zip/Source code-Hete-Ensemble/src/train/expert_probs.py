"""
专家训练与概率缓存模块 / Expert training & probability caching module.

按 LOCO 协议训练 15 个专家(每个专家 = 时间窗 × 特征域 × 选择器 × 分类器),
并将每个专家在每折测试集上的预测概率缓存到磁盘, 供后续集成评估复用。

Trains the 15 experts (each = time window × feature domain × selector × classifier)
under LOCO and caches each expert's predicted probabilities on the test fold of
every center, for reuse in downstream ensemble evaluation.

依赖 / Dependencies: numpy, pandas, scikit-learn
"""

import numpy as np
import pandas as pd
from pathlib import Path

from src.train.load_data import load_domain_features
from src.train.split import splitByCenter

from src.classifier.LR2 import build_lr_l2
from src.classifier.KNN import build_knn
from src.classifier.mlp import build_mlp
from src.classifier.XGB import build_xgb
from src.classifier.LDA import build_lda
from src.classifier.LR1 import build_lr_l1

from src.selecor.f_classif import select_f_classif
from src.selecor.MI import select_mutual_info
from src.selecor.L1 import select_l1
from src.selecor.BR import select_boruta
from src.selecor.mRMR import select_mrmr

from src.train.eval_utils import generate_expert_names

# 分类器注册表 / Classifier registry
MODELS = {
    'LR2': build_lr_l2, 'LR1': build_lr_l1, 'LDA': build_lda, 'KNN': build_knn,
    'MLP': build_mlp, 'XGB': build_xgb
}

# 特征选择器注册表 / Feature-selector registry
SELECTORS = {
    'fClassif': select_f_classif, 'mi': select_mutual_info, 'l1': select_l1,
    'boruta': select_boruta, 'mrmr': select_mrmr
}

def save_expert_probabilities(all_expert_probs, all_y_true_folds,
                              all_sample_names_folds, all_centers_folds,
                              expert_names, results_dir, base_seed):
    """
    将各专家在 LOCO 各折上的预测概率保存为 CSV /
    Save each expert's predicted probabilities per LOCO fold to CSV.
    输出结构 / Output layout: results_dir/seed_{base_seed}/{expert}/{center}.csv
    """
    root = Path(results_dir) / f'seed_{base_seed}'
    n_experts = len(all_expert_probs)
    n_folds = len(all_expert_probs[0])
    for i in range(n_experts):
        expert_dir = root / expert_names[i]
        expert_dir.mkdir(parents=True, exist_ok=True)
        for fold_idx in range(n_folds):
            center_name = str(all_centers_folds[fold_idx][0])
            pd.DataFrame({
                'sample_name': all_sample_names_folds[fold_idx],
                'y_true':      all_y_true_folds[fold_idx],
                'y_prob':      all_expert_probs[i][fold_idx],
            }).to_csv(expert_dir / f'{center_name}.csv',
                      index=False, encoding='utf-8-sig')
    print(f"\n专家预测概率已保存至: {root}")


def train_center_voting(patient_data, config):
    """
    LOCO 训练所有专家并缓存预测概率 / Train all experts under LOCO and cache predicted probabilities.

    对每个专家: 加载特征 -> LOCO 划分 -> 特征选择(仅训练集) -> 训练分类器 -> 预测测试集概率。
    For each expert: load features -> LOCO split -> feature selection (train only)
    -> train classifier -> predict test-set probabilities.
    """
    experts_config = config['experts_config']
    results_dir    = config['results_dir']
    base_seed      = config.get('base_seed', 42)

    X_list = []
    y_common = sample_names_common = None

    for i, exp_cfg in enumerate(experts_config):
        X, y, groups, names, feat_names = load_domain_features(
            patient_data, exp_cfg['feature_path'], exp_cfg['domains']
        )
        X_list.append(X)
        if i == 0:
            y_common = y
            sample_names_common = names
        else:
            assert np.array_equal(y, y_common)
            assert np.array_equal(names, sample_names_common)

    center_labels = patient_data.set_index('sample_name') \
                                .loc[sample_names_common, 'Dataset'].values

    all_expert_probs = [[] for _ in range(len(experts_config))]
    all_y_true_folds, all_centers_folds, all_sample_names_folds = [], [], []

    for train_idx, test_idx, fold_idx, center_name in splitByCenter(center_labels):
        y_test = y_common[test_idx]
        test_names = sample_names_common[test_idx]

        probs_test = []
        for i, exp_cfg in enumerate(experts_config):
            X_exp = X_list[i]
            X_train, X_test = X_exp[train_idx], X_exp[test_idx]
            y_train = y_common[train_idx]

            X_train_sel, X_test_sel, _ = SELECTORS[exp_cfg['selector']](
                X_train, y_train, X_test,
                k=exp_cfg.get('k', 40), random_seed=base_seed
            )
            model = MODELS[exp_cfg['model']](random_seed=base_seed, fold_idx=fold_idx)
            model.fit(X_train_sel, y_train)
            probs_test.append(model.predict_proba(X_test_sel)[:, 1])

        for i, prob in enumerate(probs_test):
            all_expert_probs[i].append(prob)
        all_y_true_folds.append(y_test)
        all_centers_folds.append(np.full(len(test_names), center_name))
        all_sample_names_folds.append(test_names)

    expert_names = generate_expert_names(experts_config)
    save_expert_probabilities(all_expert_probs, all_y_true_folds,
                              all_sample_names_folds, all_centers_folds,
                              expert_names, results_dir, base_seed)