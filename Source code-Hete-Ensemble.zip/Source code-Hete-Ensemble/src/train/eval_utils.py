"""
评估工具模块 / Evaluation utility module.

提供统一的评估指标计算、专家命名、概率加载/聚合、以及 ROC/PR 曲线绘制工具。
Provides unified metric computation, expert naming, probability loading/aggregation,
and ROC/PR curve plotting utilities.

依赖 / Dependencies: numpy, pandas, scikit-learn, matplotlib
"""

import numpy as np
import pandas as pd
from pathlib import Path
import re
import matplotlib as mpl
import matplotlib.pyplot as plt
from sklearn.metrics import (accuracy_score, roc_auc_score, f1_score,
                             cohen_kappa_score, matthews_corrcoef,
                             precision_score, recall_score,
                             confusion_matrix, average_precision_score,
                             roc_curve, precision_recall_curve)

METRIC_COLS = ["Accuracy", "ROC_AUC", "F1", "Kappa", "MCC", "Precision",
               "Recall", "Specificity", "NPV", "AUC_PR", "Balanced_Accuracy"]

def evaluate(y_true, y_pred, y_prob):
    """
    计算 11 项分类指标 / Compute 11 classification metrics.

    指标 / Metrics: Accuracy, ROC_AUC, F1, Kappa, MCC, Precision, Recall,
    Specificity, NPV, AUC_PR, Balanced_Accuracy=(Recall+Specificity)/2
    """
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    npv = tn / (tn + fn) if (tn + fn) > 0 else 0.0
    try:
        roc_auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        roc_auc = np.nan
    try:
        auc_pr = average_precision_score(y_true, y_prob)
    except ValueError:
        auc_pr = np.nan
    rec = recall_score(y_true, y_pred, zero_division=0)
    return {
        "Accuracy":          accuracy_score(y_true, y_pred),
        "ROC_AUC":           roc_auc,
        "F1":                f1_score(y_true, y_pred, zero_division=0),
        "Kappa":             cohen_kappa_score(y_true, y_pred),
        "MCC":               matthews_corrcoef(y_true, y_pred),
        "Precision":         precision_score(y_true, y_pred, zero_division=0),
        "Recall":            rec,
        "Specificity":       specificity,
        "NPV":               npv,
        "AUC_PR":            auc_pr,
        "Balanced_Accuracy": 0.5 * (rec + specificity),
    }

def generate_expert_names(experts_config):
    """
    根据专家配置生成命名: {window}_{model}_{selector}_{domain} /
    Generate expert names from config: {window}_{model}_{selector}_{domain}.
    """
    names = []
    for cfg in experts_config:
        name = f"{cfg['model']}_{cfg['selector']}_{cfg['domains'][0]}"
        match = re.search(r'/(\d+(?:start|mid))/', cfg['feature_path'])
        window = match.group(1) if match else 'unknown'
        names.append(f"{window}_{name}")
    return names


def list_seeds(results_dir):
    return sorted([p.name for p in Path(results_dir).iterdir()
                   if p.is_dir() and p.name.startswith('seed_')])


def list_centers(results_dir, any_expert):
    first_seed = list_seeds(results_dir)[0]
    return sorted([f.stem for f in
                   (Path(results_dir) / first_seed / any_expert).glob('*.csv')])


def load_probs(results_dir, seed, expert, center):
    df = pd.read_csv(Path(results_dir) / seed / expert / f'{center}.csv')
    return df['y_true'].values, df['y_prob'].values


def ensemble_probs(results_dir, seed, experts, center):
    """
    soft voting: 对多个专家的预测概率取算术平均 / Soft voting: average predicted probabilities across experts.

    返回 / Returns: (y_true, averaged_prob)
    """
    seed_dir = Path(results_dir) / seed
    base = pd.read_csv(seed_dir / experts[0] / f'{center}.csv')
    df = base[['sample_name', 'y_true']].copy()
    cols = []
    for e in experts:
        edf = pd.read_csv(seed_dir / e / f'{center}.csv')[['sample_name', 'y_prob']]
        col = f'p_{e}'
        df = df.merge(edf.rename(columns={'y_prob': col}), on='sample_name', how='left')
        cols.append(col)
    probs = df[cols].values.mean(axis=1)
    return df['y_true'].values, probs


def summary_by_center_seed(per_seed_center):
    df = pd.DataFrame(per_seed_center).T
    df.index.names = ['seed', 'center']
    df_center = df.groupby('center').mean()
    return pd.DataFrame({'mean': df_center.mean(), 'std': df_center.std()})


def format_ms(row):
    return {m: f"{row.loc[m, 'mean']:.4f} ± {row.loc[m, 'std']:.4f}"
            for m in row.index}

mpl.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 9,
    'axes.labelsize': 9,
    'axes.titlesize': 9,
    'legend.fontsize': 7.5,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'axes.linewidth': 0.8,
    'axes.grid': True,
    'grid.linestyle': ':',
    'grid.linewidth': 0.5,
    'grid.alpha': 0.6,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'legend.frameon': True,
    'legend.framealpha': 1.0,
    'legend.edgecolor': 'black',
    'figure.dpi': 150,
    'savefig.bbox': 'tight',
    'savefig.dpi': 300,
})


def _interp(xs, ys, n=200):
    grid = np.linspace(0, 1, n)
    interp = np.array([np.interp(grid, x, y) for x, y in zip(xs, ys)])
    return grid, interp.mean(axis=0), interp.std(axis=0)


def _curves(curves, kind):
    """curves: list of (y_true, y_prob) → (grid, mean, std)。"""
    xs, ys = [], []
    for y, p in curves:
        if len(np.unique(y)) < 2:
            continue
        if kind == 'roc':
            a, b, _ = roc_curve(y, p)
        else:
            b, a, _ = precision_recall_curve(y, p)
            a, b = a[::-1], b[::-1]     # recall 升序
        xs.append(a); ys.append(b)
    return _interp(xs, ys)


def _plot(centers_data, out_path, kind, layout):
    if kind == 'roc':
        xlabel, ylabel = 'False Positive Rate', 'True Positive Rate'
    else:
        xlabel, ylabel = 'Recall', 'Precision'

    if layout == 'grid':
        n = len(centers_data)
        rows, cols = (2, 2) if n <= 4 else (2, (n + 1) // 2)
        fig, axes = plt.subplots(rows, cols, figsize=(7.0, 5.2))
        axes = np.atleast_1d(axes).flatten()
        for ax, (center, curves) in zip(axes, centers_data.items()):
            g, m, s = _curves(curves, kind)
            ax.plot(g, m, color='C0', lw=1.2)
            ax.fill_between(g, m - s, m + s, color='C0', alpha=0.15, linewidth=0)
            if kind == 'roc':
                ax.plot([0, 1], [0, 1], 'k--', lw=0.6)
            ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02)
            ax.set_xlabel(xlabel); ax.set_ylabel(ylabel); ax.set_title(center)
        for ax in axes[len(centers_data):]:
            ax.axis('off')
    else:
        fig, ax = plt.subplots(figsize=(4.5, 3.2))
        colors = plt.cm.tab10(np.linspace(0, 1, len(centers_data)))
        for color, (center, curves) in zip(colors, centers_data.items()):
            g, m, s = _curves(curves, kind)
            ax.plot(g, m, color=color, lw=1.2, label=center)
            ax.fill_between(g, m - s, m + s, color=color, alpha=0.15, linewidth=0)
        if kind == 'roc':
            ax.plot([0, 1], [0, 1], 'k--', lw=0.6)
        ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02)
        ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
        ax.legend(loc='lower right' if kind == 'roc' else 'lower left')

    plt.tight_layout()
    fig.savefig(out_path, dpi=300, bbox_inches='tight', pad_inches=0.1)
    plt.close(fig)


def plot_roc_curves(centers_data, out_path, layout='grid'):
    _plot(centers_data, out_path, kind='roc', layout=layout)


def plot_pr_curves(centers_data, out_path, layout='grid'):
    _plot(centers_data, out_path, kind='pr', layout=layout)