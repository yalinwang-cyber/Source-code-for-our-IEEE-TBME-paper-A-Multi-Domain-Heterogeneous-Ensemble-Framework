"""
阈值扫描模块 / Threshold sweep module.

在一系列阈值(默认 0.30–0.80, 步长 0.05)上评估集成性能, 输出 threshold_scan.csv,
并绘制各中心的 Recall/Specificity–阈值曲线, 标注目标阈值 0.56。
Sweeps the ensemble over a range of thresholds (default 0.30–0.80, step 0.05),
outputs threshold_scan.csv, and plots per-center Recall/Specificity vs threshold
curves with the target threshold 0.56 marked.

依赖 / Dependencies: numpy, pandas, matplotlib, scikit-learn
"""

import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt

from src.train.eval_utils import (METRIC_COLS, evaluate, list_seeds, list_centers,
                        ensemble_probs, summary_by_center_seed)


def scan_thresholds(results_dir, expert_names,
                    thresholds=None,
                    fig_dir='figures',
                    target_threshold=0.56):
    """
    扫描 soft-voting 阈值并输出 threshold_scan.csv + 阈值曲线 /
    Sweep the soft-voting threshold; output threshold_scan.csv + threshold curves.
    """
    if thresholds is None:
        thresholds = np.round(np.arange(0.30, 0.805, 0.05), 2)

    seeds   = list_seeds(results_dir)
    centers = list_centers(results_dir, expert_names[0])
    fig_dir = Path(fig_dir); fig_dir.mkdir(exist_ok=True)

    records = []
    for t in thresholds:
        per_seed_center = {}
        for seed in seeds:
            for center in centers:
                y_true, prob = ensemble_probs(results_dir, seed, expert_names, center)
                y_pred = (prob >= t).astype(int)
                per_seed_center[(seed, center)] = evaluate(y_true, y_pred, prob)
        summary = summary_by_center_seed(per_seed_center)

        row = {'threshold': t}
        row.update({m: f"{summary.loc[m, 'mean']:.4f} ± {summary.loc[m, 'std']:.4f}"
                    for m in METRIC_COLS})
        records.append(row)
        print(f"threshold={t:.2f} done")

    df = pd.DataFrame(records)
    df.to_csv('threshold_scan.csv', index=False, encoding='utf-8-sig')
    print("\n[threshold_scan] 结果:")
    print(df[['threshold', 'ROC_AUC', 'AUC_PR', 'F1',
              'Recall', 'Specificity', 'Balanced_Accuracy']].to_string(index=False))

    rec = []
    for center in centers:
        for t in thresholds:
            vals_r, vals_s = [], []
            for seed in seeds:
                y_true, prob = ensemble_probs(results_dir, seed, expert_names, center)
                y_pred = (prob >= t).astype(int)
                m = evaluate(y_true, y_pred, prob)
                vals_r.append(m['Recall'])
                vals_s.append(m['Specificity'])
            rec.append({
                'center':      center,
                'threshold':   t,
                'Recall':      np.mean(vals_r),
                'Specificity': np.mean(vals_s),
            })

    df_curve = pd.DataFrame(rec)

    styles = {
        'Recall':      {'color': '#D95319', 'linestyle': '-'},
        'Specificity': {'color': '#0072BD', 'linestyle': '--'},
    }

    n = len(centers)
    rows, cols = (2, 2) if n <= 4 else (2, (n + 1) // 2)
    fig, axes = plt.subplots(rows, cols, figsize=(7.0, 5.2))
    axes = np.atleast_1d(axes).flatten()

    for ax, center in zip(axes, centers):
        sub = df_curve[df_curve['center'] == center].sort_values('threshold')
        for metric, sty in styles.items():
            ax.plot(sub['threshold'], sub[metric],
                    color=sty['color'], linestyle=sty['linestyle'],
                    linewidth=1.5, label=metric)
            y_t = np.interp(target_threshold, sub['threshold'], sub[metric])
            ax.scatter(target_threshold, y_t, color='red', s=22, zorder=5)

        ax.set_title(center)
        ax.set_xlabel('Threshold')
        ax.set_ylabel('Mean Value')
        ax.set_xticks(thresholds[::2])
        ax.set_ylim(0.0, 1.02)
        ax.grid(True, linestyle='--', linewidth=0.5, alpha=0.5)

    for ax in axes[n:]:
        ax.axis('off')

    axes[0].legend(frameon=False, loc='lower left')
    plt.tight_layout()
    fig.savefig(fig_dir / 'threshold_per_center.png',
                dpi=300, bbox_inches='tight', pad_inches=0.1)
    plt.close(fig)
    print(f"\n阈值曲线已保存至 {fig_dir / 'threshold_per_center.png'}")