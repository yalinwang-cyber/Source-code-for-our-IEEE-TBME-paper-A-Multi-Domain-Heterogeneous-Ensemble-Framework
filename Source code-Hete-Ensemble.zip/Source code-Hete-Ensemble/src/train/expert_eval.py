"""
单专家评估模块 / Per-expert evaluation module.

逐个专家计算 11 项指标并输出 expert_metrics.csv。
Computes the 11 metrics for each expert individually and outputs expert_metrics.csv.

依赖 / Dependencies: pandas, scikit-learn
"""

import pandas as pd

from src.train.eval_utils import (METRIC_COLS, evaluate, list_seeds, list_centers,
                        load_probs, summary_by_center_seed)


def evaluate_experts(results_dir, expert_names, threshold):
    """
    评估每个专家单独的性能并输出 expert_metrics.csv /
    Evaluate each expert individually and output expert_metrics.csv.
    """
    seeds = list_seeds(results_dir)
    centers = list_centers(results_dir, expert_names[0])

    records = []
    for expert in expert_names:
        per_seed_center = {}
        for seed in seeds:
            for center in centers:
                y_true, prob = load_probs(results_dir, seed, expert, center)
                y_pred = (prob >= threshold).astype(int)
                per_seed_center[(seed, center)] = evaluate(y_true, y_pred, prob)
        summary = summary_by_center_seed(per_seed_center)

        row = {'expert': expert}
        row.update({m: f"{summary.loc[m, 'mean']:.4f} ± {summary.loc[m, 'std']:.4f}"
                    for m in METRIC_COLS})
        records.append(row)
        print(f"done: {expert}")

    out = pd.DataFrame(records)
    out.to_csv('expert_metrics.csv', index=False, encoding='utf-8-sig')
    print("\n[expert] 单专家结果:")
    print(out[['expert', 'ROC_AUC', 'AUC_PR', 'Recall',
               'Specificity', 'Balanced_Accuracy']].to_string(index=False))