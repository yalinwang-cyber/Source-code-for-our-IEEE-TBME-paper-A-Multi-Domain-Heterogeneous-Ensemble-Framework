"""
集成整体评估模块 / Overall ensemble evaluation module.

对所有专家做 soft voting, 计算各中心与 Overall 的 11 项指标, 并绘制 ROC/PR 曲线。
Performs soft voting over all experts, computes the 11 metrics per center and overall,
and plots ROC/PR curves.

依赖 / Dependencies: pandas, scikit-learn, matplotlib
"""

import pandas as pd
from pathlib import Path

from src.train.eval_utils import (METRIC_COLS, evaluate, list_seeds, list_centers,
                        ensemble_probs, summary_by_center_seed,
                        plot_roc_curves, plot_pr_curves)


def evaluate_ensemble(results_dir, expert_names, threshold, fig_dir='figures'):
    """
    评估整体集成(soft voting)并输出 ensemble_metrics.csv + 曲线 /
    Evaluate the overall ensemble (soft voting); output ensemble_metrics.csv + curves.
    """
    seeds = list_seeds(results_dir)
    centers = list_centers(results_dir, expert_names[0])
    fig_dir = Path(fig_dir); fig_dir.mkdir(exist_ok=True)

    per_seed_center = {}
    for seed in seeds:
        for center in centers:
            y_true, prob = ensemble_probs(results_dir, seed, expert_names, center)
            y_pred = (prob >= threshold).astype(int)
            per_seed_center[(seed, center)] = evaluate(y_true, y_pred, prob)

    summary = summary_by_center_seed(per_seed_center)

    df = pd.DataFrame(per_seed_center).T
    df.index.names = ['seed', 'center']
    per_center = df.groupby('center').mean()

    rows = []
    for c in per_center.index:
        row = {'center': c}
        row.update({m: f"{per_center.loc[c, m]:.4f}" for m in METRIC_COLS})
        rows.append(row)
    row = {'center': 'Overall'}
    row.update({m: f"{summary.loc[m, 'mean']:.4f} ± {summary.loc[m, 'std']:.4f}"
                for m in METRIC_COLS})
    rows.append(row)

    out = pd.DataFrame(rows)
    out.to_csv('ensemble_metrics.csv', index=False, encoding='utf-8-sig')
    print("\n[ensemble] 各中心 + Overall:")
    print(out.to_string(index=False))

    centers_data = {}
    for center in centers:
        centers_data[center] = []
        for seed in seeds:
            y_true, prob = ensemble_probs(results_dir, seed, expert_names, center)
            centers_data[center].append((y_true, prob))

    plot_roc_curves(centers_data, fig_dir / 'ensemble_roc_per_center.png',
                    layout='overlay')
    plot_pr_curves(centers_data, fig_dir / 'ensemble_pr_per_center.png',
                   layout='overlay')
    plot_roc_curves(centers_data, fig_dir / 'ensemble_roc_grid.png',
                    layout='grid')
    plot_pr_curves(centers_data, fig_dir / 'ensemble_pr_grid.png',
                   layout='grid')